import { useState, type ReactNode } from 'react';
import { Link, NavLink, Outlet } from 'react-router-dom';
import { Boxes, ExternalLink, FileText, History, Inbox, LayoutDashboard, LogOut, Menu, ShieldCheck, Tags, Users, X } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { useI18n } from '../lib/i18n';
import { useTitle } from '../lib/useTitle';
import { cn } from '../lib/utils';
import { Button, EmptyState, Spinner } from '../components/ui';
import { LangToggle } from '../components/site/Layout';

export function AdminLayout() {
  const { t } = useI18n();
  const { status, user, profile, can, isOwner, hasAdminAccess, signIn, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  const [error, setError] = useState('');
  useTitle(t('admin.title'));

  if (status === 'loading') return <div className="grid min-h-dvh place-items-center bg-mist"><Spinner label={t('common.loading')} /></div>;

  if (!user || !hasAdminAccess) {
    return (
      <div className="on-dark grid min-h-dvh place-items-center bg-pine px-5">
        <div className="w-full max-w-md rounded-[10px] bg-white p-9 text-center text-ink shadow-2xl">
          <img src="/brand/logo.png" alt="نسيم العطاء" width={218} height={40} className="mx-auto h-10 w-auto" />
          {!user ? (
            <>
              <h1 className="mt-7 text-2xl font-semibold text-pine">{t('login.title')}</h1>
              <p className="mt-2 text-sm text-muted">{t('login.text')}</p>
              <Button size="lg" className="mt-7 w-full" onClick={async () => { const e = await signIn(); setError(e ? t('login.error', { code: e }) : ''); }}>
                <ShieldCheck className="size-5" aria-hidden />{t('login.google')}
              </Button>
              {error && <p role="alert" className="mt-4 text-sm font-medium text-danger">{error}</p>}
            </>
          ) : (
            <EmptyState
              title={t('login.deniedTitle')}
              text={t('login.deniedText', { email: user.email || '' })}
              action={<Button variant="outline" onClick={() => void signOut()}>{t('login.switch')}</Button>}
            />
          )}
          <Link to="/" className="mt-6 inline-block text-sm text-teal-d hover:underline">{t('login.backToSite')}</Link>
        </div>
      </div>
    );
  }

  const items = [
    { to: '/admin', label: t('admin.nav.dashboard'), icon: LayoutDashboard, end: true, show: true },
    { to: '/admin/products', label: t('admin.nav.products'), icon: Boxes, show: can('products:view') },
    { to: '/admin/categories', label: t('admin.nav.categories'), icon: Tags, show: can('categories:view') },
    { to: '/admin/content', label: t('admin.nav.content'), icon: FileText, show: can('content:view') },
    { to: '/admin/messages', label: t('admin.nav.messages'), icon: Inbox, show: can('messages:view') },
    { to: '/admin/staff', label: t('admin.nav.staff'), icon: Users, show: can('staff:view') },
    { to: '/admin/activity', label: t('admin.nav.activity'), icon: History, show: can('audit:view') },
  ].filter((i) => i.show);

  const nav = (
    <nav className="flex flex-col gap-1 px-3" aria-label="Admin">
      {items.map(({ to, label, icon: Icon, end }) => (
        <NavLink key={to} to={to} end={end} onClick={() => setOpen(false)}
          className={({ isActive }) => cn('flex items-center gap-3 rounded-[5px] px-3.5 py-2.5 text-[15px] font-medium transition-colors', isActive ? 'bg-white/12 text-sand' : 'text-white/80 hover:bg-white/8 hover:text-white')}>
          <Icon className="size-[18px]" aria-hidden />{label}
        </NavLink>
      ))}
    </nav>
  );

  return (
    <div className="flex min-h-dvh bg-mist">
      <aside className="on-dark sticky top-0 hidden h-dvh w-64 shrink-0 flex-col bg-pine py-5 lg:flex">
        <Link to="/admin" className="mx-5 mb-6 block rounded-[6px] bg-white px-3 py-2"><img src="/brand/logo.png" alt="نسيم العطاء" className="h-8 w-auto" /></Link>
        {nav}
      </aside>

      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button className="absolute inset-0 bg-pine/60" onClick={() => setOpen(false)} aria-label={t('common.close')} />
          <aside className="on-dark absolute inset-y-0 start-0 w-72 bg-pine py-5">
            <button className="absolute end-3 top-3 text-white" onClick={() => setOpen(false)} aria-label={t('common.close')}><X className="size-6" /></button>
            <div className="mx-5 mb-6 w-44 rounded-[6px] bg-white px-3 py-2"><img src="/brand/logo.png" alt="" className="h-8 w-auto" /></div>
            {nav}
          </aside>
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b border-line bg-white px-4 md:px-8">
          <button className="rounded p-2 lg:hidden" onClick={() => setOpen(true)} aria-label={t('nav.menu')}><Menu className="size-6" /></button>
          <div className="hidden text-sm lg:block">
            <p className="font-semibold text-pine">{profile?.name || user.displayName}</p>
            <p className="text-xs text-muted">{isOwner ? t('role.owner') : profile?.jobTitle}</p>
          </div>
          <div className="ms-auto flex items-center gap-2">
            <Link to="/" target="_blank" className="hidden items-center gap-1.5 rounded-[5px] px-3 py-1.5 text-sm text-muted hover:bg-tint sm:inline-flex"><ExternalLink className="size-4" aria-hidden />{t('admin.viewSite')}</Link>
            <LangToggle />
            <button onClick={() => void signOut()} className="inline-flex items-center gap-1.5 rounded-[5px] px-3 py-1.5 text-sm text-danger hover:bg-[#f7e3e1]"><LogOut className="size-4" aria-hidden /><span className="hidden sm:inline">{t('admin.signOut')}</span></button>
          </div>
        </header>
        <main className="flex-1 p-4 md:p-8"><Outlet /></main>
      </div>
    </div>
  );
}

/** Wrap an admin page so it only renders for users holding the permission. */
export function RequirePermission({ perm, children }: { perm: string; children: ReactNode }) {
  const { can } = useAuth();
  const { t } = useI18n();
  if (!can(perm)) return <EmptyState title={t('admin.forbiddenTitle')} text={t('admin.forbiddenText')} icon={<ShieldCheck className="size-10" aria-hidden />} />;
  return <>{children}</>;
}

export function PageTitle({ title, text, action }: { title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-semibold text-pine md:text-3xl">{title}</h1>
        {text && <p className="mt-1 text-sm text-muted">{text}</p>}
      </div>
      {action}
    </div>
  );
}
