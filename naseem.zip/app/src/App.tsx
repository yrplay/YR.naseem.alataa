import { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import { I18nProvider } from './lib/i18n';
import { AuthProvider } from './lib/auth';
import { SiteProvider } from './lib/data';
import { ToastProvider, Spinner } from './components/ui';
import { SiteLayout } from './components/site/Layout';
import { AdminLayout, RequirePermission } from './admin/AdminLayout';
import HomePage from './pages/HomePage';
import ProductsPage from './pages/ProductsPage';
import ProductPage from './pages/ProductPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import PageView, { NotFound } from './pages/PageView';

// Admin screens are loaded on demand so visitors never download them.
const Dashboard = lazy(() => import('./pages/admin/Dashboard'));
const ProductsAdmin = lazy(() => import('./pages/admin/ProductsAdmin'));
const CategoriesAdmin = lazy(() => import('./pages/admin/CategoriesAdmin'));
const ContentAdmin = lazy(() => import('./pages/admin/ContentAdmin'));
const MessagesAdmin = lazy(() => import('./pages/admin/MessagesAdmin'));
const StaffAdmin = lazy(() => import('./pages/admin/StaffAdmin'));
const ActivityAdmin = lazy(() => import('./pages/admin/ActivityAdmin'));

const guard = (perm: string, el: React.ReactNode) => <RequirePermission perm={perm}>{el}</RequirePermission>;

export function App() {
  return (
    <I18nProvider>
      <ToastProvider>
        <AuthProvider>
          <SiteProvider>
            <Suspense fallback={<Spinner />}>
              <Routes>
                <Route element={<SiteLayout />}>
                  <Route index element={<HomePage />} />
                  <Route path="products" element={<ProductsPage />} />
                  <Route path="products/:id" element={<ProductPage />} />
                  <Route path="about" element={<AboutPage />} />
                  <Route path="contact" element={<ContactPage />} />
                  <Route path="p/:id" element={<PageView />} />
                  <Route path="*" element={<NotFound />} />
                </Route>
                <Route path="admin" element={<AdminLayout />}>
                  <Route index element={<Dashboard />} />
                  <Route path="products" element={guard('products:view', <ProductsAdmin />)} />
                  <Route path="categories" element={guard('categories:view', <CategoriesAdmin />)} />
                  <Route path="content" element={guard('content:view', <ContentAdmin />)} />
                  <Route path="messages" element={guard('messages:view', <MessagesAdmin />)} />
                  <Route path="staff" element={guard('staff:view', <StaffAdmin />)} />
                  <Route path="activity" element={guard('audit:view', <ActivityAdmin />)} />
                </Route>
              </Routes>
            </Suspense>
          </SiteProvider>
        </AuthProvider>
      </ToastProvider>
    </I18nProvider>
  );
}
