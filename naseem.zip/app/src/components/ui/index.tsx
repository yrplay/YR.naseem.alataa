import {
  createContext, useCallback, useContext, useEffect, useRef, useState,
  type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode, type SelectHTMLAttributes, type TextareaHTMLAttributes,
} from 'react';
import { CheckCircle2, ImagePlus, Loader2, X, XCircle } from 'lucide-react';
import { useI18n } from '../../lib/i18n';
import { cn, fileToDataUrl } from '../../lib/utils';
import type { L } from '../../lib/types';

/* ---------- Button ---------- */
type Variant = 'primary' | 'accent' | 'outline' | 'ghost' | 'danger';
const variants: Record<Variant, string> = {
  primary: 'bg-teal text-white hover:bg-teal-d',
  accent: 'bg-sand text-pine hover:bg-[#c4a06e]',
  outline: 'border border-line bg-white text-ink hover:border-teal hover:text-teal-d',
  ghost: 'text-ink hover:bg-tint',
  danger: 'bg-danger text-white hover:bg-[#962a21]',
};
export function Button({
  variant = 'primary', size = 'md', loading, className, children, disabled, ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: 'sm' | 'md' | 'lg'; loading?: boolean }) {
  return (
    <button
      {...rest}
      disabled={disabled || loading}
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-[5px] font-medium transition-colors disabled:cursor-not-allowed disabled:opacity-50',
        size === 'sm' && 'px-3 py-1.5 text-sm',
        size === 'md' && 'px-5 py-2.5 text-[15px]',
        size === 'lg' && 'px-7 py-3.5 text-base',
        variants[variant],
        className,
      )}
    >
      {loading && <Loader2 className="size-4 animate-spin" aria-hidden />}
      {children}
    </button>
  );
}

/* ---------- Form controls ---------- */
const controlCls =
  'w-full rounded-[5px] border border-line bg-white px-3.5 py-2.5 text-[15px] text-ink placeholder:text-muted/60 focus:border-teal focus:outline-none focus:ring-2 focus:ring-teal/25 disabled:bg-mist disabled:text-muted';

export function Field({ label, hint, error, children, className }: { label: string; hint?: string; error?: string; children: ReactNode; className?: string }) {
  return (
    <label className={cn('block', className)}>
      <span className="mb-1.5 block text-sm font-medium text-ink">{label}</span>
      {children}
      {hint && !error && <span className="mt-1 block text-xs text-muted">{hint}</span>}
      {error && <span className="mt-1 block text-xs font-medium text-danger">{error}</span>}
    </label>
  );
}
export const Input = (p: InputHTMLAttributes<HTMLInputElement>) => <input {...p} className={cn(controlCls, p.className)} />;
export const Textarea = (p: TextareaHTMLAttributes<HTMLTextAreaElement>) => <textarea {...p} className={cn(controlCls, 'resize-y', p.className)} />;
export const Select = (p: SelectHTMLAttributes<HTMLSelectElement>) => <select {...p} className={cn(controlCls, 'pe-8', p.className)} />;

export function Switch({ checked, onChange, label, disabled }: { checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }) {
  return (
    <label className={cn('inline-flex cursor-pointer items-center gap-3 text-sm', disabled && 'cursor-not-allowed opacity-50')}>
      <button
        type="button" role="switch" aria-checked={checked} disabled={disabled} onClick={() => onChange(!checked)}
        className={cn('relative h-6 w-11 shrink-0 rounded-full transition-colors', checked ? 'bg-teal' : 'bg-line')}
      >
        <span className={cn('absolute top-0.5 size-5 rounded-full bg-white shadow transition-all', checked ? 'start-[22px]' : 'start-0.5')} />
      </button>
      <span>{label}</span>
    </label>
  );
}

/** Bilingual content field: Arabic and English side by side, stored as one `{ar, en}` object. */
export function LField({ label, value, onChange, multiline, rows = 3, required, max }: {
  label: string; value: L; onChange: (v: L) => void; multiline?: boolean; rows?: number; required?: boolean; max?: number;
}) {
  const { t } = useI18n();
  const props = (lang: 'ar' | 'en') => ({
    value: value[lang],
    maxLength: max,
    required: required && lang === 'ar',
    dir: (lang === 'ar' ? 'rtl' : 'ltr') as 'rtl' | 'ltr',
    lang,
    onChange: (e: { target: { value: string } }) => onChange({ ...value, [lang]: e.target.value }),
  });
  return (
    <fieldset className="min-w-0">
      <legend className="mb-1.5 text-sm font-medium text-ink">{label}</legend>
      <div className="grid gap-2 sm:grid-cols-2">
        {(['ar', 'en'] as const).map((lang) => (
          <div key={lang}>
            <span className="mb-1 block text-xs text-muted">{lang === 'ar' ? t('common.arabic') : t('common.english')}</span>
            {multiline ? <Textarea rows={rows} {...props(lang)} /> : <Input {...props(lang)} />}
          </div>
        ))}
      </div>
    </fieldset>
  );
}

/* ---------- Badge / spinner / empty ---------- */
export function Badge({ tone = 'neutral', children }: { tone?: 'neutral' | 'good' | 'warn' | 'brand'; children: ReactNode }) {
  const tones = { neutral: 'bg-tint text-muted', good: 'bg-[#d8efe2] text-[#1d6b45]', warn: 'bg-[#f6e6c9] text-sand-d', brand: 'bg-teal text-white' };
  return <span className={cn('inline-flex items-center rounded-[3px] px-2 py-0.5 text-xs font-medium', tones[tone])}>{children}</span>;
}
export function Spinner({ label }: { label?: string }) {
  return (
    <div role="status" className="flex items-center justify-center gap-2 py-16 text-muted">
      <Loader2 className="size-5 animate-spin" aria-hidden />
      {label && <span className="text-sm">{label}</span>}
    </div>
  );
}
export function EmptyState({ title, text, action, icon }: { title: string; text?: string; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center px-6 py-14 text-center">
      {icon && <div className="mb-4 text-teal">{icon}</div>}
      <h3 className="text-lg font-semibold text-pine">{title}</h3>
      {text && <p className="mt-2 text-sm text-muted">{text}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

/* ---------- Modal (native <dialog>: focus trap + Esc for free) ---------- */
export function Modal({ open, onClose, title, children, footer, wide }: { open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  const ref = useRef<HTMLDialogElement>(null);
  const { t } = useI18n();
  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) d.showModal();
    if (!open && d.open) d.close();
  }, [open]);
  return (
    <dialog
      ref={ref}
      onClose={onClose}
      onClick={(e) => e.target === ref.current && onClose()}
      className={cn('m-auto max-h-[92dvh] w-[calc(100%-1.5rem)] overflow-hidden rounded-[8px] bg-white p-0 text-ink shadow-2xl', wide ? 'max-w-3xl' : 'max-w-lg')}
    >
      {open && (
        <div className="flex max-h-[92dvh] flex-col">
          <header className="flex items-center justify-between border-b border-line px-6 py-4">
            <h2 className="text-lg font-semibold text-pine">{title}</h2>
            <button onClick={onClose} className="rounded p-1 text-muted hover:bg-tint" aria-label={t('common.close')}><X className="size-5" /></button>
          </header>
          <div className="overflow-y-auto px-6 py-5">{children}</div>
          {footer && <footer className="flex flex-wrap justify-end gap-2 border-t border-line bg-mist px-6 py-3">{footer}</footer>}
        </div>
      )}
    </dialog>
  );
}

export function ConfirmDialog({ open, title, text, confirmLabel, onConfirm, onClose }: {
  open: boolean; title: string; text: string; confirmLabel: string; onConfirm: () => Promise<void> | void; onClose: () => void;
}) {
  const { t } = useI18n();
  const [busy, setBusy] = useState(false);
  return (
    <Modal
      open={open} onClose={onClose} title={title}
      footer={
        <>
          <Button variant="outline" onClick={onClose}>{t('common.cancel')}</Button>
          <Button variant="danger" loading={busy} onClick={async () => { setBusy(true); try { await onConfirm(); } finally { setBusy(false); onClose(); } }}>{confirmLabel}</Button>
        </>
      }
    >
      <p className="text-[15px] text-muted">{text}</p>
    </Modal>
  );
}

/* ---------- Toasts ---------- */
interface ToastItem { id: number; kind: 'ok' | 'error'; text: string }
const ToastCtx = createContext<(kind: 'ok' | 'error', text: string) => void>(() => undefined);
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const push = useCallback((kind: 'ok' | 'error', text: string) => {
    const id = Date.now() + Math.random();
    setItems((s) => [...s, { id, kind, text }]);
    setTimeout(() => setItems((s) => s.filter((i) => i.id !== id)), 4500);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="pointer-events-none fixed inset-x-0 bottom-4 z-[100] flex flex-col items-center gap-2 px-4" aria-live="polite">
        {items.map((i) => (
          <div key={i.id} className={cn('pointer-events-auto flex max-w-md items-center gap-2.5 rounded-[6px] px-4 py-3 text-sm font-medium text-white shadow-xl', i.kind === 'ok' ? 'bg-pine' : 'bg-danger')}>
            {i.kind === 'ok' ? <CheckCircle2 className="size-5 text-sand" /> : <XCircle className="size-5" />}
            {i.text}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

/* ---------- Images (stored compressed inside Firestore documents) ---------- */
export function ImageField({ label, value, onChange, maxSide = 1400, maxChars = 220000, hint }: {
  label: string; value: string; onChange: (v: string) => void; maxSide?: number; maxChars?: number; hint?: string;
}) {
  const { t } = useI18n();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const pick = async (file?: File) => {
    if (!file) return;
    setBusy(true);
    try { onChange(await fileToDataUrl(file, maxSide, maxChars)); }
    catch { toast('error', t('image.error')); }
    finally { setBusy(false); }
  };
  return (
    <div>
      <span className="mb-1.5 block text-sm font-medium">{label}</span>
      <div className="flex items-center gap-3">
        <div className="flex size-24 shrink-0 items-center justify-center overflow-hidden rounded-[6px] border border-dashed border-line bg-mist">
          {value ? <img src={value} alt="" className="size-full object-cover" /> : <ImagePlus className="size-6 text-muted" aria-hidden />}
        </div>
        <div className="space-y-2">
          <label className="inline-flex cursor-pointer items-center gap-2 rounded-[5px] border border-line bg-white px-3 py-1.5 text-sm hover:border-teal">
            {busy ? <Loader2 className="size-4 animate-spin" /> : <ImagePlus className="size-4" />}
            {value ? t('image.replace') : t('image.choose')}
            <input type="file" accept="image/*" className="sr-only" onChange={(e) => { void pick(e.target.files?.[0]); e.target.value = ''; }} />
          </label>
          {value && <button type="button" onClick={() => onChange('')} className="block text-xs text-danger hover:underline">{t('image.remove')}</button>}
          {hint && <p className="text-xs text-muted">{hint}</p>}
        </div>
      </div>
    </div>
  );
}

export function GalleryField({ label, images, onChange, max = 4 }: { label: string; images: string[]; onChange: (v: string[]) => void; max?: number }) {
  const { t } = useI18n();
  const toast = useToast();
  const [busy, setBusy] = useState(false);
  const add = async (files: FileList | null) => {
    if (!files?.length) return;
    setBusy(true);
    try {
      const next = [...images];
      for (const f of Array.from(files)) {
        if (next.length >= max) break;
        next.push(await fileToDataUrl(f, 1100, 200000));
      }
      onChange(next);
    } catch { toast('error', t('image.error')); }
    finally { setBusy(false); }
  };
  return (
    <div>
      <span className="mb-1.5 block text-sm font-medium">{label}</span>
      <div className="flex flex-wrap gap-3">
        {images.map((src, i) => (
          <div key={i} className="group relative size-24 overflow-hidden rounded-[6px] border border-line">
            <img src={src} alt="" className="size-full object-cover" />
            {i === 0 && <span className="absolute inset-x-0 bottom-0 bg-pine/80 py-0.5 text-center text-[11px] text-white">{t('image.main')}</span>}
            <button type="button" onClick={() => onChange(images.filter((_, j) => j !== i))} className="absolute end-1 top-1 rounded bg-white/90 p-0.5 text-danger" aria-label={t('image.remove')}><X className="size-4" /></button>
          </div>
        ))}
        {images.length < max && (
          <label className="flex size-24 cursor-pointer flex-col items-center justify-center gap-1 rounded-[6px] border border-dashed border-line bg-mist text-xs text-muted hover:border-teal hover:text-teal-d">
            {busy ? <Loader2 className="size-5 animate-spin" /> : <ImagePlus className="size-5" />}
            {t('image.add')}
            <input type="file" accept="image/*" multiple className="sr-only" onChange={(e) => { void add(e.target.files); e.target.value = ''; }} />
          </label>
        )}
      </div>
      <p className="mt-1.5 text-xs text-muted">{t('image.galleryHint', { n: max })}</p>
    </div>
  );
}
