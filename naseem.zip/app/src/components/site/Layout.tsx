import { useEffect, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import { Languages, LayoutDashboard, Mail, MapPin, Menu, Phone, X } from 'lucide-react';
import { useI18n } from '../../lib/i18n';
import { useSite } from '../../lib/data';
import { useAuth } from '../../lib/auth';
import { cn } from '../../lib/utils';

export function LangToggle({ className }: { className?: string }) {
  const { lang, toggle, t } = useI18n();
  return (
    <button
      onClick={toggle}
      lang={lang === 'ar' ? 'en' : 'ar'}
      className={cn('inline-flex items-center gap-1.5 rounded-[5px] border border-line px-3 py-1.5 text-sm font-medium hover:border-teal hover:text-teal-d', className)}
      aria-label={t('nav.switchLang')}
    >
      <Languages className="size-4" aria-hidden />
      {lang === 'ar' ? 'English' : 'العربية'}
    </button>
  );
}

function Header() {
  const { t } = useI18n();
  const { hasAdminAccess } = useAuth();
  const [open, setOpen] = useState(false);
  const links = [
    { to: '/', label: t('nav.home'), end: true },
    { to: '/products', label: t('nav.products') },
    { to: '/about', label: t('nav.about') },
    { to: '/contact', label: t('nav.contact') },
  ];
  const linkCls = ({ isActive }: { isActive: boolean }) =>
    cn('relative px-1 py-2 text-[15px] font-medium transition-colors hover:text-teal-d', isActive ? 'text-teal-d after:absolute after:inset-x-0 after:-bottom-px after:h-0.5 after:bg-sand' : 'text-ink');
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-white/95 backdrop-blur">
      <div className="mx-auto flex h-[68px] max-w-7xl items-center justify-between gap-4 px-5">
        <Link to="/" aria-label={t('nav.home')} className="shrink-0">
          <img src="/brand/logo.png" alt="نسيم العطاء Naseem Alataa" width={218} height={40} className="h-10 w-auto" />
        </Link>
        <nav className="hidden items-center gap-7 md:flex" aria-label="Main">
          {links.map((l) => <NavLink key={l.to} to={l.to} end={l.end} className={linkCls}>{l.label}</NavLink>)}
        </nav>
        <div className="hidden items-center gap-2 md:flex">
          {hasAdminAccess && (
            <Link to="/admin" className="inline-flex items-center gap-1.5 rounded-[5px] bg-pine px-3.5 py-1.5 text-sm font-medium text-white hover:bg-pine-2">
              <LayoutDashboard className="size-4" aria-hidden />{t('nav.admin')}
            </Link>
          )}
          <LangToggle />
        </div>
        <button className="rounded p-2 md:hidden" onClick={() => setOpen((v) => !v)} aria-expanded={open} aria-label={t('nav.menu')}>
          {open ? <X className="size-6" /> : <Menu className="size-6" />}
        </button>
      </div>
      {open && (
        <div className="border-t border-line bg-white px-5 pb-5 md:hidden">
          <nav className="flex flex-col py-2" aria-label="Mobile">
            {links.map((l) => <NavLink key={l.to} to={l.to} end={l.end} onClick={() => setOpen(false)} className={({ isActive }) => cn('border-b border-line py-3 font-medium', isActive && 'text-teal-d')}>{l.label}</NavLink>)}
          </nav>
          <div className="mt-3 flex gap-2">
            {hasAdminAccess && <Link to="/admin" onClick={() => setOpen(false)} className="rounded-[5px] bg-pine px-3.5 py-2 text-sm font-medium text-white">{t('nav.admin')}</Link>}
            <LangToggle />
          </div>
        </div>
      )}
    </header>
  );
}

function Footer() {
  const { t, tr } = useI18n();
  const { settings, pages } = useSite();
  const c = settings.company;
  const social = Object.entries(c.social).filter(([, v]) => v);
  return (
    <footer className="mt-24 border-t border-line bg-white">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <img src="/brand/logo.png" alt="" width={218} height={40} className="h-10 w-auto" />
          <p className="mt-5 max-w-sm text-sm text-muted">{tr(settings.hero.subtitle)}</p>
          {social.length > 0 && (
            <ul className="mt-5 flex flex-wrap gap-2">
              {social.map(([k, v]) => (
                <li key={k}><a href={v} target="_blank" rel="noopener noreferrer" className="slant-tab inline-block bg-tint px-4 py-1 text-xs font-medium capitalize hover:bg-teal hover:text-white">{k === 'x' ? 'X' : k}</a></li>
              ))}
            </ul>
          )}
        </div>
        <div>
          <h2 className="mb-4 text-base font-semibold text-pine">{t('footer.contact')}</h2>
          <ul className="space-y-3 text-sm">
            {tr(c.address) && <li className="flex gap-2.5"><MapPin className="mt-0.5 size-4 shrink-0 text-sand-d" aria-hidden />{tr(c.address)}</li>}
            {c.phone && <li className="flex gap-2.5"><Phone className="mt-0.5 size-4 shrink-0 text-sand-d" aria-hidden /><a href={`tel:${c.phone}`} dir="ltr" className="hover:text-teal-d">{c.phone}</a></li>}
            {c.email && <li className="flex gap-2.5"><Mail className="mt-0.5 size-4 shrink-0 text-sand-d" aria-hidden /><a href={`mailto:${c.email}`} className="hover:text-teal-d">{c.email}</a></li>}
          </ul>
        </div>
        <div>
          <h2 className="mb-4 text-base font-semibold text-pine">{t('footer.links')}</h2>
          <ul className="space-y-2.5 text-sm">
            <li><Link to="/products" className="hover:text-teal-d">{t('nav.products')}</Link></li>
            <li><Link to="/about" className="hover:text-teal-d">{t('nav.about')}</Link></li>
            <li><Link to="/contact" className="hover:text-teal-d">{t('nav.contact')}</Link></li>
            {pages.filter((p) => p.published).map((p) => <li key={p.id}><Link to={`/p/${p.id}`} className="hover:text-teal-d">{tr(p.title)}</Link></li>)}
          </ul>
        </div>
      </div>
      <div className="border-t border-line py-4 text-center text-xs text-muted">
        {t('footer.rights', { year: new Date().getFullYear(), name: tr(c.name) })}
      </div>
    </footer>
  );
}

export function SiteLayout() {
  const { pathname } = useLocation();
  const { t } = useI18n();
  // scroll to top on route change
  useScrollTop(pathname);
  return (
    <div className="flex min-h-dvh flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:start-3 focus:top-3 focus:z-50 focus:rounded focus:bg-sand focus:px-4 focus:py-2 focus:text-pine">{t('nav.skip')}</a>
      <Header />
      <main id="main" className="flex-1"><Outlet /></main>
      <Footer />
    </div>
  );
}

function useScrollTop(key: string) {
  useEffect(() => { window.scrollTo({ top: 0 }); }, [key]);
}
