import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { useI18n } from '../../lib/i18n';
import { useSite } from '../../lib/data';
import { formatPrice } from '../../lib/utils';
import type { Product } from '../../lib/types';

export function Container({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`mx-auto max-w-7xl px-5 ${className}`}>{children}</div>;
}

export function SectionHead({ title, text, action }: { title: string; text?: string; action?: ReactNode }) {
  return (
    <div className="mb-10 flex flex-wrap items-end justify-between gap-4">
      <div className="max-w-2xl">
        <h2 className="text-3xl font-semibold text-pine md:text-4xl">{title}</h2>
        {text && <p className="mt-3 text-muted">{text}</p>}
      </div>
      {action}
    </div>
  );
}

/** Quiet page title block used by inner pages. */
export function PageHead({ title, text }: { title: string; text?: string }) {
  return (
    <div className="on-dark relative overflow-hidden bg-pine text-white">
      <div aria-hidden className="absolute inset-y-0 end-[8%] hidden w-24 -skew-x-[16deg] bg-teal/40 md:block" />
      <div aria-hidden className="absolute inset-y-0 end-[18%] hidden w-10 -skew-x-[16deg] bg-sand/50 md:block" />
      <Container className="relative py-14 md:py-20">
        <h1 className="text-4xl font-semibold md:text-5xl">{title}</h1>
        {text && <p className="mt-4 max-w-2xl text-white/75">{text}</p>}
      </Container>
    </div>
  );
}

/** Image-less placeholder: the official square logo, faded into the background. */
export function LogoPlaceholder() {
  return (
    <div className="flex size-full items-center justify-center bg-mist">
      <img src="/brand/logo-square.jpeg" alt="" className="size-2/3 object-contain opacity-60 mix-blend-multiply" />
    </div>
  );
}

export function ProductCard({ product }: { product: Product }) {
  const { tr, lang } = useI18n();
  const { categories } = useSite();
  const cat = categories.find((c) => c.id === product.categoryId);
  return (
    <Link to={`/products/${product.id}`} className="group flex flex-col overflow-hidden rounded-[6px] border border-line bg-white transition-shadow hover:shadow-[0_10px_30px_-12px_rgb(11_47_51/0.35)]">
      <div className="aspect-[4/3] overflow-hidden">
        {product.thumb ? <img src={product.thumb} alt={tr(product.title)} loading="lazy" className="size-full object-cover transition-transform duration-500 group-hover:scale-[1.03]" /> : <LogoPlaceholder />}
      </div>
      <div className="flex flex-1 flex-col gap-1 border-t-[3px] border-sand p-4">
        {cat && <span className="text-xs font-medium text-teal-d">{tr(cat.title)}</span>}
        <h3 className="text-[17px] font-semibold text-pine">{tr(product.title)}</h3>
        {product.price != null && <p className="mt-auto pt-2 text-[15px] font-semibold text-sand-d">{formatPrice(product.price, lang)}</p>}
      </div>
    </Link>
  );
}
