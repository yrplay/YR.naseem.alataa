import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Web config values are public identifiers (not secrets). Access is enforced by firestore.rules.
// Override any of them with VITE_* variables; the fallbacks are the project already used by this app.
const env = import.meta.env;
const config = {
  apiKey: env.VITE_FIREBASE_API_KEY || 'AIzaSyCaylWqgWp7P7RA5UrVH7-7egAUC17lNfI',
  authDomain: env.VITE_FIREBASE_AUTH_DOMAIN || 'peerless-reason-1f38q.firebaseapp.com',
  projectId: env.VITE_FIREBASE_PROJECT_ID || 'peerless-reason-1f38q',
  appId: env.VITE_FIREBASE_APP_ID || '1:251912504639:web:86157b479b98f573253f8a',
};
const databaseId: string =
  env.VITE_FIREBASE_DATABASE_ID ?? 'ai-studio-naseemalataatrad-d6feeb26-e908-44a9-85f8-e42039f055dd';

const app = initializeApp(config);
export const db = databaseId ? getFirestore(app, databaseId) : getFirestore(app);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export const OWNER_EMAIL: string = (env.VITE_OWNER_EMAIL || 'yr.play.com@gmail.com').toLowerCase();
