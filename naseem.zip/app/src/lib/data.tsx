import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { collection, doc, onSnapshot, query, where, type Query } from 'firebase/firestore';
import { db } from './firebase';
import { useAuth } from './auth';
import { emptyL, type Category, type PageDoc, type Product, type SiteSettings } from './types';

export const EMPTY_SETTINGS: SiteSettings = {
  company: {
    name: { ar: 'نسيم العطاء', en: 'Naseem Al-Ataa' },
    address: emptyL(), phone: '', whatsapp: '', email: '', mapUrl: '',
    social: { x: '', instagram: '', linkedin: '', youtube: '', facebook: '', tiktok: '' },
  },
  hero: { title: emptyL(), subtitle: emptyL(), image: '' },
  about: { intro: emptyL(), vision: emptyL(), mission: emptyL(), values: emptyL(), image: '' },
  services: [],
  sectors: [],
};

function mergeSettings(raw: Partial<SiteSettings>): SiteSettings {
  const d = EMPTY_SETTINGS;
  return {
    ...d,
    ...raw,
    company: { ...d.company, ...raw.company, social: { ...d.company.social, ...raw.company?.social } },
    hero: { ...d.hero, ...raw.hero },
    about: { ...d.about, ...raw.about },
    services: raw.services ?? [],
    sectors: raw.sectors ?? [],
  };
}

/** Subscribe to a query. Pass `null` to stay idle (e.g. when the user lacks permission). */
export function useLive<T>(q: Query | null, deps: unknown[]): { data: Array<T & { id: string }>; loading: boolean; failed: boolean } {
  const [state, setState] = useState<{ data: Array<T & { id: string }>; loading: boolean; failed: boolean }>({ data: [], loading: !!q, failed: false });
  useEffect(() => {
    if (!q) {
      setState({ data: [], loading: false, failed: false });
      return;
    }
    setState((s) => ({ ...s, loading: true }));
    return onSnapshot(
      q,
      (snap) => setState({ data: snap.docs.map((d) => ({ ...(d.data() as T), id: d.id })), loading: false, failed: false }),
      () => setState({ data: [], loading: false, failed: true }),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return state;
}

interface SiteValue {
  settings: SiteSettings;
  /** false until the first server answer arrives */
  loaded: boolean;
  /** true when nobody has saved site content yet */
  isBlank: boolean;
  categories: Category[];
  products: Product[];
  pages: PageDoc[];
  catalogLoading: boolean;
  /** true when the Firestore requests failed (rules not deployed, offline ...) */
  failed: boolean;
}

const Ctx = createContext<SiteValue | null>(null);

export function SiteProvider({ children }: { children: ReactNode }) {
  const { can } = useAuth();
  const seeAllProducts = can('products:view');
  const seeAllCategories = can('categories:view');
  const seeAllPages = can('content:view');

  const [settings, setSettings] = useState<SiteSettings>(EMPTY_SETTINGS);
  const [loaded, setLoaded] = useState(false);
  const [isBlank, setBlank] = useState(true);
  const [settingsFailed, setSettingsFailed] = useState(false);

  useEffect(
    () =>
      onSnapshot(
        doc(db, 'settings', 'site'),
        (snap) => {
          setBlank(!snap.exists());
          setSettings(snap.exists() ? mergeSettings(snap.data() as Partial<SiteSettings>) : EMPTY_SETTINGS);
          setLoaded(true);
        },
        () => {
          setSettingsFailed(true);
          setLoaded(true);
        },
      ),
    [],
  );

  const cats = useLive<Omit<Category, 'id'>>(
    seeAllCategories ? collection(db, 'categories') : query(collection(db, 'categories'), where('active', '==', true)),
    [seeAllCategories],
  );
  const prods = useLive<Omit<Product, 'id'>>(
    seeAllProducts ? collection(db, 'products') : query(collection(db, 'products'), where('active', '==', true)),
    [seeAllProducts],
  );
  const pgs = useLive<Omit<PageDoc, 'id'>>(
    seeAllPages ? collection(db, 'pages') : query(collection(db, 'pages'), where('published', '==', true)),
    [seeAllPages],
  );

  const categories = useMemo(
    () => [...cats.data].sort((a, b) => (a.order ?? 0) - (b.order ?? 0)) as Category[],
    [cats.data],
  );
  const products = useMemo(
    () =>
      [...prods.data].sort(
        (a, b) => (a.order ?? 1e9) - (b.order ?? 1e9) || (b.createdAt?.toMillis() ?? 0) - (a.createdAt?.toMillis() ?? 0),
      ) as Product[],
    [prods.data],
  );

  const value = useMemo<SiteValue>(
    () => ({
      settings, loaded, isBlank, categories, products,
      pages: pgs.data as PageDoc[],
      catalogLoading: cats.loading || prods.loading,
      failed: settingsFailed || cats.failed || prods.failed,
    }),
    [settings, loaded, isBlank, categories, products, pgs.data, cats.loading, prods.loading, settingsFailed, cats.failed, prods.failed],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSite(): SiteValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useSite must be used inside <SiteProvider>');
  return v;
}
