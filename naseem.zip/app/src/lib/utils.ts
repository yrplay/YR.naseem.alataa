import type { L, Lang } from './types';

export const cn = (...v: Array<string | false | null | undefined>) => v.filter(Boolean).join(' ');

/** Pick the text for the current language, falling back to the other one when empty. */
export function tr(l: L | undefined | null, lang: Lang): string {
  if (!l) return '';
  return (l[lang] || l[lang === 'ar' ? 'en' : 'ar'] || '').trim();
}

export const lines = (text: string): string[] => text.split(/\n+/).map((s) => s.trim()).filter(Boolean);

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60);
}

export const isValidSlug = (s: string) => /^[a-z0-9-]{2,60}$/.test(s);
export const isEmail = (s: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s);
export const uid = () => Math.random().toString(36).slice(2, 10);

export function formatPrice(value: number | null | undefined, lang: Lang): string {
  if (value == null) return '';
  return new Intl.NumberFormat(lang === 'ar' ? 'ar-SA' : 'en-US', { style: 'currency', currency: 'SAR', maximumFractionDigits: 2 }).format(value);
}

export function formatDate(ts: { toDate: () => Date } | undefined, lang: Lang): string {
  if (!ts) return '';
  return new Intl.DateTimeFormat(lang === 'ar' ? 'ar-SA' : 'en-GB', { dateStyle: 'medium', timeStyle: 'short' }).format(ts.toDate());
}

/**
 * Resize and compress an image in the browser. Images are stored inside Firestore documents,
 * so every upload is capped by size to stay far below the 1 MB document limit.
 */
export async function fileToDataUrl(file: File, maxSide: number, maxChars: number): Promise<string> {
  if (!file.type.startsWith('image/')) throw new Error('not-image');
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('canvas');
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  for (const q of [0.82, 0.72, 0.62, 0.5, 0.4]) {
    const out = canvas.toDataURL('image/webp', q);
    if (out.length <= maxChars) return out;
  }
  throw new Error('too-large');
}

/** Re-encode an existing data URL as a small thumbnail (used for product list cards). */
export async function dataUrlToThumb(dataUrl: string, maxSide = 520, maxChars = 60000): Promise<string> {
  const blob = await (await fetch(dataUrl)).blob();
  return fileToDataUrl(new File([blob], 'thumb', { type: blob.type }), maxSide, maxChars);
}

/** Accepts either a Google Maps embed URL or the full <iframe> snippet; returns a safe URL or ''. */
export function extractMapUrl(input: string): string {
  const raw = input.trim();
  const m = raw.match(/src=["']([^"']+)["']/i);
  const url = (m ? m[1] : raw).trim();
  return /^https:\/\/www\.google\.com\/maps\/embed\?/.test(url) ? url : '';
}

export const waLink = (phone: string) => `https://wa.me/${phone.replace(/[^\d]/g, '')}`;
