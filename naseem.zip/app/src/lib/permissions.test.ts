import { describe, expect, it } from 'vitest';
import { ALL_PERMISSIONS, ROLES, hasPermission, normalizePermissions } from './permissions';
import { dict } from './dict';

describe('permissions', () => {
  it('edit/create/delete imply view', () => {
    expect(normalizePermissions(['products:edit'])).toEqual(['products:view', 'products:edit']);
    expect(normalizePermissions(['audit:view'])).toEqual(['audit:view']);
  });
  it('drops unknown permissions', () => {
    expect(normalizePermissions(['hack:all', 'content:view'])).toEqual(['content:view']);
  });
  it('inactive staff have no access; owner always does', () => {
    expect(hasPermission({ active: false, permissions: ALL_PERMISSIONS }, 'products:view')).toBe(false);
    expect(hasPermission(null, 'staff:manage', true)).toBe(true);
    expect(hasPermission({ active: true, permissions: ['messages:view'] }, 'messages:manage')).toBe(false);
  });
  it('role presets only contain valid permissions', () => {
    for (const r of Object.values(ROLES)) for (const p of r.permissions) expect(ALL_PERMISSIONS).toContain(p);
  });
});

describe('dictionary', () => {
  it('has Arabic and English for every key', () => {
    for (const [k, [ar, en]] of Object.entries(dict)) {
      expect(ar.trim(), k).not.toBe('');
      expect(en.trim(), k).not.toBe('');
    }
  });
});
