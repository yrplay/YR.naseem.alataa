import type { Timestamp } from 'firebase/firestore';

export type Lang = 'ar' | 'en';
/** Every user-facing content field is stored as one bilingual object. */
export type L = { ar: string; en: string };
export const emptyL = (): L => ({ ar: '', en: '' });

export interface Item {
  id: string;
  title: L;
  text: L;
}

export interface SiteSettings {
  company: {
    name: L;
    address: L;
    phone: string;
    whatsapp: string;
    email: string;
    mapUrl: string;
    social: { x: string; instagram: string; linkedin: string; youtube: string; facebook: string; tiktok: string };
  };
  hero: { title: L; subtitle: L; image: string };
  about: { intro: L; vision: L; mission: L; values: L; image: string };
  services: Item[];
  sectors: Item[];
  updatedAt?: Timestamp;
  updatedBy?: string;
}

export interface Category {
  id: string;
  title: L;
  description: L;
  order: number;
  active: boolean;
  thumb?: string;
}

export interface Product {
  id: string;
  title: L;
  description: L;
  categoryId: string;
  price: number | null;
  sku?: string;
  featured: boolean;
  active: boolean;
  order?: number;
  thumb?: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface PageDoc {
  id: string; // slug
  title: L;
  body: L;
  published: boolean;
  updatedAt?: Timestamp;
}

export interface Message {
  id: string;
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
  read: boolean;
  createdAt?: Timestamp;
}

export type Role = 'owner' | 'admin' | 'products_manager' | 'content_editor' | 'support' | 'custom';

export interface StaffProfile {
  email: string;
  name: string;
  jobTitle: string;
  role: Role;
  permissions: string[];
  active: boolean;
  addedBy: string;
  createdAt?: Timestamp;
  updatedAt?: Timestamp;
}

export interface AuditEntry {
  id: string;
  actor: string;
  actorName: string;
  action: string;
  target: string;
  at?: Timestamp;
}
