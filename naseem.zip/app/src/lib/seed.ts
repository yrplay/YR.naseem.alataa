import type { Category, SiteSettings } from './types';

/**
 * Starting content imported once by the owner from the admin dashboard.
 * Text only: no products and no images (the official logo is the only visual asset).
 */
export const SEED_SETTINGS: Omit<SiteSettings, 'updatedAt' | 'updatedBy'> = {
  company: {
    name: { ar: 'شركة نسيم العطاء التجارية', en: 'Naseem Al-Ataa Trading Company' },
    address: { ar: 'المملكة العربية السعودية - مكة المكرمة - حي الملك فهد', en: 'Makkah, Saudi Arabia - King Fahd District' },
    phone: '+966555433512',
    whatsapp: '',
    email: 'info@naseemalata.sa',
    mapUrl: '',
    social: { x: '', instagram: '', linkedin: '', youtube: '', facebook: '', tiktok: '' },
  },
  hero: {
    title: { ar: 'جودة يمكنك الوثوق بها', en: 'Quality you can trust' },
    subtitle: {
      ar: 'شريكك في تنفيذ المشاريع وتوريد المواد الغذائية، بحلول متكاملة تلبي احتياجات عملك.',
      en: 'Your partner in project delivery and food supply, with complete solutions built around your business.',
    },
    image: '',
  },
  about: {
    intro: {
      ar: 'تأسست شركة نسيم العطاء التجارية في 11 ديسمبر 2016، ومقرها الرئيسي في مكة المكرمة. نتخصص في تنفيذ المشاريع وتقديم الحلول والخدمات المتكاملة على مدار العام.\n\nلدينا خبرة واسعة في المشاريع السنوية والموسمية، وتشمل خدماتنا التجهيز والتوريد والتوزيع والتنفيذ الميداني لصالح الجهات والشركات، ومنها مشاريع الحج والعمرة وقطاع الضيافة.\n\nنبني شراكات طويلة الأمد قائمة على الجودة والكفاءة والالتزام، ونعمل مع الفنادق وشركات التموين والإعاشة ومصانع الأغذية ومتاجر التجزئة والجهات الحكومية.',
      en: 'Naseem Al-Ataa Trading Company was founded on 11 December 2016 and is headquartered in Makkah. We specialise in project delivery and integrated solutions and services throughout the year.\n\nWe have broad experience in annual and seasonal projects. Our services cover preparation, supply, distribution and field execution for organisations and companies, including Hajj and Umrah projects and the hospitality sector.\n\nWe build long-term partnerships grounded in quality, efficiency and commitment, working with hotels, catering companies, food manufacturers, retailers and government bodies.',
    },
    vision: {
      ar: 'أن نكون الخيار الأول لتنفيذ المشاريع وتوفير الحلول والخدمات المتكاملة في مختلف القطاعات.',
      en: 'To be the first choice for project delivery and integrated solutions and services across sectors.',
    },
    mission: {
      ar: 'تنفيذ وإدارة المشاريع وتقديم حلول وخدمات متكاملة بكفاءة وجودة وابتكار، لضمان رضا العملاء وتطوير قدرات الموظفين وخلق قيمة مستدامة.',
      en: 'To execute and manage projects and deliver integrated solutions and services with efficiency, quality and innovation, ensuring client satisfaction, developing our people and creating lasting value.',
    },
    values: {
      ar: 'الكفاءة\nالإنتاجية\nالموثوقية\nالمرونة\nالطموح\nالابتكار\nالجودة\nالاستجابة',
      en: 'Efficiency\nProductivity\nReliability\nFlexibility\nAmbition\nInnovation\nQuality\nResponsiveness',
    },
    image: '',
  },
  services: [
    { id: 'svc-projects', title: { ar: 'تنفيذ وإدارة المشاريع', en: 'Project execution and management' }, text: { ar: 'تخطيط وتجهيز وتنفيذ وإدارة المشاريع السنوية والموسمية لمختلف القطاعات.', en: 'Planning, preparing, delivering and managing annual and seasonal projects for different sectors.' } },
    { id: 'svc-trading', title: { ar: 'التجارة العامة والتوريدات', en: 'General trading and supplies' }, text: { ar: 'توريد المواد الغذائية والمستلزمات بالجملة وفق أعلى معايير الجودة.', en: 'Wholesale supply of food products and necessities to the highest quality standards.' } },
    { id: 'svc-catering', title: { ar: 'الإعاشة والتموين', en: 'Catering and provisions' }, text: { ar: 'تجهيز وتقديم الوجبات والإعاشة للمناسبات والمواسم والجهات.', en: 'Preparing and serving meals and provisions for events, seasons and organisations.' } },
    { id: 'svc-community', title: { ar: 'المشاريع الخيرية والمجتمعية', en: 'Charitable and community projects' }, text: { ar: 'تنفيذ البرامج والمبادرات الخيرية والمجتمعية بالتعاون مع الجهات المختصة.', en: 'Delivering charitable and community programmes in cooperation with the relevant bodies.' } },
    { id: 'svc-logistics', title: { ar: 'الدعم التشغيلي واللوجستي', en: 'Operational and logistical support' }, text: { ar: 'خدمات النقل والتخزين والتوزيع والدعم الميداني للمشاريع.', en: 'Transport, storage, distribution and field support for projects.' } },
  ],
  sectors: [
    { id: 'sec-supermarkets', title: { ar: 'السوبر ماركت', en: 'Supermarkets' }, text: { ar: 'منتجات غذائية طازجة ومجمدة ومعبأة بتوريد منتظم وأسعار تنافسية.', en: 'Fresh, frozen and packaged food with reliable supply and competitive pricing.' } },
    { id: 'sec-restaurants', title: { ar: 'المطاعم', en: 'Restaurants' }, text: { ar: 'مكونات عالية الجودة تدعم ثبات الطعم وسلاسة التشغيل.', en: 'High-quality ingredients that keep taste consistent and kitchens running smoothly.' } },
    { id: 'sec-hotels', title: { ar: 'الفنادق', en: 'Hotels' }, text: { ar: 'حلول توريد غذائي متكاملة للفنادق والمنتجعات.', en: 'Complete food supply solutions for hotels and resorts.' } },
    { id: 'sec-catering', title: { ar: 'شركات التموين والإعاشة', en: 'Catering companies' }, text: { ar: 'توريد بالجملة يلبي احتياجات الإعاشة الكبيرة والمواسم.', en: 'Bulk supply that meets large-scale and seasonal catering needs.' } },
    { id: 'sec-manufacturers', title: { ar: 'مصانع الأغذية', en: 'Food manufacturers' }, text: { ar: 'مواد خام فاخرة تشمل الحبوب والتوابل والزيوت.', en: 'Premium raw materials including grains, spices and oils.' } },
    { id: 'sec-retail', title: { ar: 'متاجر التجزئة', en: 'Retail stores' }, text: { ar: 'توزيع بالجملة يساعد المتاجر على توفير منتجات متنوعة وموثوقة.', en: 'Wholesale distribution that helps stores offer a varied, dependable range.' } },
    { id: 'sec-government', title: { ar: 'التوريد الحكومي', en: 'Government supply' }, text: { ar: 'حلول توريد موثوقة للجهات الحكومية والمؤسسات العامة.', en: 'Dependable supply solutions for government bodies and public institutions.' } },
    { id: 'sec-healthcare', title: { ar: 'القطاع الصحي', en: 'Healthcare' }, text: { ar: 'منتجات غذائية للمستشفيات والمرافق الصحية والعيادات.', en: 'Food products for hospitals, healthcare facilities and clinics.' } },
  ],
};

export const SEED_CATEGORIES: Array<Omit<Category, 'thumb'>> = [
  { id: 'food-baskets', order: 1, active: true, title: { ar: 'السلال الغذائية', en: 'Food baskets' }, description: { ar: 'تأمين وتجهيز وتوزيع السلال الغذائية للأسر والمستفيدين.', en: 'Procuring, preparing and distributing food baskets to families and beneficiaries.' } },
  { id: 'water-provision', order: 2, active: true, title: { ar: 'سقيا الماء', en: 'Water provision' }, description: { ar: 'تنفيذ مشاريع سقيا الماء وتوزيع المياه في المواقع المستهدفة.', en: 'Delivering water supply projects and distributing water at targeted locations.' } },
  { id: 'iftar-meals', order: 3, active: true, title: { ar: 'إفطار الصائمين', en: 'Iftar meals' }, description: { ar: 'تجهيز وتوزيع وجبات الإفطار خلال شهر رمضان.', en: 'Preparing and distributing iftar meals during Ramadan.' } },
  { id: 'pilgrim-meals', order: 4, active: true, title: { ar: 'إطعام الحجاج والمعتمرين', en: 'Pilgrim meals' }, description: { ar: 'تجهيز وتوزيع الوجبات لضيوف الرحمن.', en: 'Preparing and distributing meals for pilgrims and visitors.' } },
  { id: 'spices-herbs', order: 5, active: true, title: { ar: 'التوابل والأعشاب', en: 'Spices & herbs' }, description: { ar: 'توابل وأعشاب فاخرة بأنواع متعددة.', en: 'A wide range of premium spices and herbs.' } },
  { id: 'pulses-lentils', order: 6, active: true, title: { ar: 'البقوليات والعدس', en: 'Pulses & lentils' }, description: { ar: 'الحمص والعدس وغيرها من البقوليات عالية الجودة.', en: 'Chickpeas, lentils and other high-quality pulses.' } },
  { id: 'cooking-oils', order: 7, active: true, title: { ar: 'زيوت الطبخ', en: 'Cooking oils' }, description: { ar: 'مجموعة متكاملة من زيوت الطبخ الفاخرة.', en: 'A complete range of premium cooking oils.' } },
  { id: 'zakat-al-fitr', order: 8, active: true, title: { ar: 'زكاة الفطر', en: 'Zakat al-Fitr' }, description: { ar: 'تجهيز وتوزيع المواد الغذائية للمستحقين وفق متطلبات الجهات المختصة.', en: 'Preparing and distributing food to eligible families as required by the relevant authorities.' } },
  { id: 'winter-clothing', order: 9, active: true, title: { ar: 'الكسوة الشتوية', en: 'Winter clothing' }, description: { ar: 'توفير وتوزيع الملابس والمستلزمات الشتوية.', en: 'Providing and distributing winter clothing and supplies.' } },
  { id: 'school-bags', order: 10, active: true, title: { ar: 'الحقائب المدرسية', en: 'School bags' }, description: { ar: 'تجهيز وتوزيع الحقائب والمستلزمات الدراسية.', en: 'Preparing and distributing school bags and supplies.' } },
  { id: 'seasonal-gifts', order: 11, active: true, title: { ar: 'الهدايا والمستلزمات الموسمية', en: 'Seasonal gifts & supplies' }, description: { ar: 'تجهيز وتوزيع الهدايا والحقائب للمستفيدين.', en: 'Preparing and distributing gifts and bags for beneficiaries.' } },
  { id: 'community-initiatives', order: 12, active: true, title: { ar: 'المبادرات المجتمعية', en: 'Community initiatives' }, description: { ar: 'تنفيذ البرامج والمبادرات الخيرية والمجتمعية.', en: 'Delivering charitable and community programmes and initiatives.' } },
];
