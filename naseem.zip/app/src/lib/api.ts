import {
  addDoc, collection, deleteDoc, doc, getDoc, serverTimestamp, setDoc, updateDoc, type Timestamp,
} from 'firebase/firestore';
import { db } from './firebase';
import { normalizePermissions } from './permissions';
import { SEED_CATEGORIES, SEED_SETTINGS } from './seed';
import type { Category, PageDoc, Product, SiteSettings, StaffProfile } from './types';

let actor = { email: '', name: '' };
export function setActor(email: string, name: string) {
  actor = { email, name };
}

/** Firestore rejects `undefined`; drop those keys (and empty optional strings handled by callers). */
function clean<T extends Record<string, unknown>>(obj: T): T {
  return Object.fromEntries(Object.entries(obj).filter(([, v]) => v !== undefined)) as T;
}

/** Best-effort activity log; a logging failure must never block the real action. */
async function audit(action: string, target: string) {
  if (!actor.email) return;
  try {
    await addDoc(collection(db, 'audit'), {
      actor: actor.email,
      actorName: actor.name.slice(0, 80),
      action,
      target: target.slice(0, 200),
      at: serverTimestamp(),
    });
  } catch {
    /* ignore */
  }
}

// ---------- products ----------
export async function saveProduct(
  data: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>,
  opts: { id?: string; createdAt?: Timestamp; images: string[] },
): Promise<string> {
  const ref = opts.id ? doc(db, 'products', opts.id) : doc(collection(db, 'products'));
  const payload = clean({
    ...data,
    createdAt: opts.createdAt ?? serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  await setDoc(ref, payload);
  if (opts.images.length) await setDoc(doc(db, 'productMedia', ref.id), { images: opts.images });
  else if (opts.id) await deleteDoc(doc(db, 'productMedia', ref.id)).catch(() => undefined);
  await audit(opts.id ? 'product.update' : 'product.create', data.title.ar || data.title.en);
  return ref.id;
}

export async function deleteProduct(p: Product) {
  await deleteDoc(doc(db, 'products', p.id));
  await deleteDoc(doc(db, 'productMedia', p.id)).catch(() => undefined);
  await audit('product.delete', p.title.ar || p.title.en);
}

export async function loadProductImages(id: string): Promise<string[]> {
  try {
    const snap = await getDoc(doc(db, 'productMedia', id));
    return snap.exists() ? ((snap.data().images as string[]) ?? []) : [];
  } catch {
    return [];
  }
}

// ---------- categories ----------
export async function saveCategory(data: Omit<Category, 'id'>, id?: string): Promise<string> {
  const ref = id ? doc(db, 'categories', id) : doc(collection(db, 'categories'));
  await setDoc(ref, clean({ ...data }));
  await audit(id ? 'category.update' : 'category.create', data.title.ar || data.title.en);
  return ref.id;
}

export async function deleteCategory(c: Category) {
  await deleteDoc(doc(db, 'categories', c.id));
  await audit('category.delete', c.title.ar || c.title.en);
}

// ---------- site content ----------
export async function saveSettings(s: Omit<SiteSettings, 'updatedAt' | 'updatedBy'>) {
  await setDoc(doc(db, 'settings', 'site'), { ...s, updatedAt: serverTimestamp(), updatedBy: actor.email });
  await audit('settings.update', 'site');
}

export async function savePage(p: Omit<PageDoc, 'updatedAt'>) {
  const { id, ...rest } = p;
  await setDoc(doc(db, 'pages', id), { ...rest, updatedAt: serverTimestamp() });
  await audit('page.save', id);
}

export async function deletePage(id: string) {
  await deleteDoc(doc(db, 'pages', id));
  await audit('page.delete', id);
}

/** One-time import of the starting texts (company info, about, services, categories). Never overwrites. */
export async function importInitialContent(): Promise<{ settings: boolean; categories: number }> {
  let settings = false;
  const site = await getDoc(doc(db, 'settings', 'site'));
  if (!site.exists()) {
    await saveSettings(SEED_SETTINGS);
    settings = true;
  }
  let categories = 0;
  for (const c of SEED_CATEGORIES) {
    const ref = doc(db, 'categories', c.id);
    if ((await getDoc(ref)).exists()) continue;
    const { id: _id, ...rest } = c;
    void _id;
    await setDoc(ref, rest);
    categories++;
  }
  await audit('content.import', `${categories} categories`);
  return { settings, categories };
}

// ---------- messages ----------
export async function sendMessage(m: { name: string; email: string; phone: string; subject: string; message: string }) {
  await addDoc(collection(db, 'messages'), { ...m, read: false, createdAt: serverTimestamp() });
}
export async function setMessageRead(id: string, read: boolean) {
  await updateDoc(doc(db, 'messages', id), { read });
}
export async function deleteMessage(id: string, from: string) {
  await deleteDoc(doc(db, 'messages', id));
  await audit('message.delete', from);
}

// ---------- staff ----------
export async function saveStaff(
  s: Pick<StaffProfile, 'email' | 'name' | 'jobTitle' | 'role' | 'permissions' | 'active'>,
  existing?: StaffProfile,
) {
  const email = s.email.trim().toLowerCase();
  await setDoc(doc(db, 'staff', email), {
    email,
    name: s.name.trim(),
    jobTitle: s.jobTitle.trim(),
    role: s.role,
    permissions: normalizePermissions(s.permissions),
    active: s.active,
    addedBy: existing?.addedBy || actor.email,
    createdAt: existing?.createdAt ?? serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  await audit(existing ? 'staff.update' : 'staff.create', email);
}

export async function deleteStaff(email: string) {
  await deleteDoc(doc(db, 'staff', email));
  await audit('staff.delete', email);
}

// ---------- quick toggles ----------
export async function setProductActive(id: string, active: boolean, title: string) {
  await updateDoc(doc(db, 'products', id), { active, updatedAt: serverTimestamp() });
  await audit(active ? 'product.show' : 'product.hide', title);
}
export async function setCategoryActive(id: string, active: boolean, title: string) {
  await updateDoc(doc(db, 'categories', id), { active });
  await audit(active ? 'category.show' : 'category.hide', title);
}
