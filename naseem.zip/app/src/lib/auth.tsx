import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut as fbSignOut, type User } from 'firebase/auth';
import { doc, onSnapshot, serverTimestamp, setDoc } from 'firebase/firestore';
import { auth, db, googleProvider, OWNER_EMAIL } from './firebase';
import { ALL_PERMISSIONS, anyAdminAccess, hasPermission } from './permissions';
import { setActor } from './api';
import type { StaffProfile } from './types';

type Status = 'loading' | 'signed-out' | 'ready';

interface AuthValue {
  status: Status;
  user: User | null;
  profile: StaffProfile | null;
  isOwner: boolean;
  hasAdminAccess: boolean;
  can: (permission: string) => boolean;
  signIn: () => Promise<string | null>;
  signOut: () => Promise<void>;
}

const Ctx = createContext<AuthValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<StaffProfile | null>(null);
  const [status, setStatus] = useState<Status>('loading');

  useEffect(
    () =>
      onAuthStateChanged(auth, (u) => {
        setUser(u);
        if (!u) {
          setProfile(null);
          setStatus('signed-out');
        }
      }),
    [],
  );

  const email = user?.emailVerified ? (user.email || '').toLowerCase() : '';
  const isOwner = !!email && email === OWNER_EMAIL;

  useEffect(() => {
    if (!email) return;
    return onSnapshot(
      doc(db, 'staff', email),
      (snap) => {
        if (snap.exists()) {
          setProfile({ ...(snap.data() as StaffProfile), email });
        } else {
          setProfile(null);
          // First sign-in of the owner creates their own record (allowed by firestore.rules).
          if (email === OWNER_EMAIL) {
            void setDoc(doc(db, 'staff', email), {
              email,
              name: user?.displayName || 'Owner',
              jobTitle: 'Owner',
              role: 'owner',
              permissions: ALL_PERMISSIONS,
              active: true,
              addedBy: email,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            }).catch(() => undefined);
          }
        }
        setStatus('ready');
      },
      () => {
        setProfile(null);
        setStatus('ready');
      },
    );
  }, [email, user?.displayName]);

  useEffect(() => {
    setActor(email, profile?.name || user?.displayName || email);
  }, [email, profile?.name, user?.displayName]);

  const can = useCallback((p: string) => hasPermission(profile, p, isOwner), [profile, isOwner]);

  const signIn = useCallback(async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      return null;
    } catch (e) {
      const code = (e as { code?: string }).code || 'unknown';
      return code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request' ? null : code;
    }
  }, []);

  const value = useMemo<AuthValue>(
    () => ({
      status,
      user,
      profile,
      isOwner,
      hasAdminAccess: anyAdminAccess(profile, isOwner),
      can,
      signIn,
      signOut: () => fbSignOut(auth),
    }),
    [status, user, profile, isOwner, can, signIn],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthValue {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth must be used inside <AuthProvider>');
  return v;
}
