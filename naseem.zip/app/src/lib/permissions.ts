import type { L, Role, StaffProfile } from './types';

/**
 * One permission = "<resource>:<action>". The same strings are enforced on the server
 * in firestore.rules, so hiding a button in the UI is never the only protection.
 */
export const PERMISSION_GROUPS = [
  { key: 'products', label: { ar: 'المنتجات', en: 'Products' }, actions: ['view', 'create', 'edit', 'delete'] },
  { key: 'categories', label: { ar: 'التصنيفات', en: 'Categories' }, actions: ['view', 'create', 'edit', 'delete'] },
  { key: 'content', label: { ar: 'محتوى الموقع والصفحات', en: 'Site content & pages' }, actions: ['view', 'edit'] },
  { key: 'messages', label: { ar: 'رسائل التواصل', en: 'Contact messages' }, actions: ['view', 'manage'] },
  { key: 'staff', label: { ar: 'الموظفون والصلاحيات', en: 'Staff & permissions' }, actions: ['view', 'manage'] },
  { key: 'audit', label: { ar: 'سجل النشاط', en: 'Activity log' }, actions: ['view'] },
] as const;

export const ACTION_LABELS: Record<string, L> = {
  view: { ar: 'عرض', en: 'View' },
  create: { ar: 'إضافة', en: 'Create' },
  edit: { ar: 'تعديل', en: 'Edit' },
  delete: { ar: 'حذف', en: 'Delete' },
  manage: { ar: 'إدارة', en: 'Manage' },
};

export const ALL_PERMISSIONS: string[] = PERMISSION_GROUPS.flatMap((g) => g.actions.map((a) => `${g.key}:${a}`));

const pick = (...groups: string[]) => ALL_PERMISSIONS.filter((p) => groups.includes(p.split(':')[0]));

export const ROLES: Record<Role, { label: L; description: L; permissions: string[] }> = {
  owner: {
    label: { ar: 'المالك', en: 'Owner' },
    description: { ar: 'تحكم كامل لا يمكن سحبه.', en: 'Full control that cannot be revoked.' },
    permissions: ALL_PERMISSIONS,
  },
  admin: {
    label: { ar: 'مدير', en: 'Admin' },
    description: { ar: 'كل الصلاحيات بما فيها إدارة الموظفين.', en: 'Everything, including managing staff.' },
    permissions: ALL_PERMISSIONS,
  },
  products_manager: {
    label: { ar: 'مسؤول المنتجات', en: 'Products manager' },
    description: { ar: 'يدير المنتجات والتصنيفات بالكامل.', en: 'Fully manages products and categories.' },
    permissions: pick('products', 'categories'),
  },
  content_editor: {
    label: { ar: 'محرر محتوى', en: 'Content editor' },
    description: { ar: 'يعدّل نصوص الموقع والصفحات، ويطّلع على المنتجات.', en: 'Edits site text and pages; can view products.' },
    permissions: ['content:view', 'content:edit', 'products:view', 'categories:view'],
  },
  support: {
    label: { ar: 'خدمة العملاء', en: 'Support agent' },
    description: { ar: 'يستقبل رسائل التواصل ويديرها.', en: 'Receives and manages contact messages.' },
    permissions: ['messages:view', 'messages:manage'],
  },
  custom: {
    label: { ar: 'مخصص', en: 'Custom' },
    description: { ar: 'اختر الصلاحيات واحدة واحدة.', en: 'Pick each permission yourself.' },
    permissions: [],
  },
};

/** Anything that changes data needs to be able to see it, so edit/create/delete imply view. */
export function normalizePermissions(perms: string[]): string[] {
  const set = new Set(perms.filter((p) => ALL_PERMISSIONS.includes(p)));
  for (const p of [...set]) {
    const [res] = p.split(':');
    if (res !== 'audit') set.add(`${res}:view`);
  }
  return ALL_PERMISSIONS.filter((p) => set.has(p));
}

export function hasPermission(profile: Pick<StaffProfile, 'active' | 'permissions'> | null, perm: string, isOwner = false): boolean {
  if (isOwner) return true;
  return !!profile && profile.active && profile.permissions.includes(perm);
}

export function anyAdminAccess(profile: StaffProfile | null, isOwner: boolean): boolean {
  return isOwner || (!!profile && profile.active && profile.permissions.length > 0);
}
