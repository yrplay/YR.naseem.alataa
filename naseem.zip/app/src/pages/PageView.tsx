import { Link, useParams } from 'react-router-dom';
import { useI18n } from '../lib/i18n';
import { useSite } from '../lib/data';
import { useTitle } from '../lib/useTitle';
import { lines } from '../lib/utils';
import { Button, EmptyState, Spinner } from '../components/ui';
import { Container, PageHead } from '../components/site/parts';

export default function PageView() {
  const { id = '' } = useParams();
  const { t, tr } = useI18n();
  const { pages, loaded } = useSite();
  const page = pages.find((p) => p.id === id && p.published);
  useTitle(page ? tr(page.title) : t('page.notFound'));
  if (!loaded) return <Spinner />;
  if (!page) return <NotFound />;
  return (
    <>
      <PageHead title={tr(page.title)} />
      <Container className="py-14">
        <article className="prose-ar max-w-3xl text-[17px] leading-8 text-ink/90">
          {lines(tr(page.body)).map((p, i) => <p key={i}>{p}</p>)}
        </article>
      </Container>
    </>
  );
}

export function NotFound() {
  const { t } = useI18n();
  return (
    <Container className="py-24">
      <EmptyState title={t('page.notFound')} text={t('page.notFoundText')} action={<Link to="/"><Button>{t('nav.home')}</Button></Link>} />
    </Container>
  );
}
