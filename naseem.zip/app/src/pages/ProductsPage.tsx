import { useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { PackageSearch, Search } from 'lucide-react';
import { useI18n } from '../lib/i18n';
import { useSite } from '../lib/data';
import { useTitle } from '../lib/useTitle';
import { cn } from '../lib/utils';
import { EmptyState, Spinner } from '../components/ui';
import { Container, PageHead, ProductCard } from '../components/site/parts';

export default function ProductsPage() {
  const { t, tr } = useI18n();
  const { products, categories, catalogLoading } = useSite();
  const [params, setParams] = useSearchParams();
  const cat = params.get('cat') || '';
  const q = (params.get('q') || '').trim().toLowerCase();
  useTitle(t('nav.products'));

  const set = (key: string, value: string) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value); else next.delete(key);
    setParams(next, { replace: true });
  };

  const visible = useMemo(
    () => products.filter((p) => p.active && (!cat || p.categoryId === cat) &&
      (!q || `${p.title.ar} ${p.title.en} ${p.description.ar} ${p.description.en} ${p.sku ?? ''}`.toLowerCase().includes(q))),
    [products, cat, q],
  );
  const activeCats = categories.filter((c) => c.active);

  return (
    <>
      <PageHead title={t('nav.products')} text={t('products.subtitle')} />
      <Container className="py-12">
        <div className="mb-8 flex flex-col gap-5 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap gap-2" role="group" aria-label={t('products.filter')}>
            <button onClick={() => set('cat', '')} className={cn('slant-tab px-5 py-2 text-sm font-medium transition-colors', !cat ? 'bg-pine text-white' : 'bg-white text-ink hover:bg-tint')}>{t('products.all')}</button>
            {activeCats.map((c) => (
              <button key={c.id} onClick={() => set('cat', c.id)} className={cn('slant-tab px-5 py-2 text-sm font-medium transition-colors', cat === c.id ? 'bg-pine text-white' : 'bg-white text-ink hover:bg-tint')}>{tr(c.title)}</button>
            ))}
          </div>
          <label className="relative block md:w-72">
            <span className="sr-only">{t('products.search')}</span>
            <Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted" aria-hidden />
            <input
              type="search" defaultValue={params.get('q') || ''} placeholder={t('products.search')}
              onChange={(e) => set('q', e.target.value)}
              className="w-full rounded-[5px] border border-line bg-white py-2.5 pe-3 ps-10 text-[15px] focus:border-teal focus:outline-none focus:ring-2 focus:ring-teal/25"
            />
          </label>
        </div>

        {catalogLoading ? <Spinner label={t('common.loading')} /> : visible.length === 0 ? (
          <EmptyState
            icon={<PackageSearch className="size-10" aria-hidden />}
            title={products.length === 0 ? t('products.emptyTitle') : t('products.noMatchTitle')}
            text={products.length === 0 ? t('products.emptyText') : t('products.noMatchText')}
          />
        ) : (
          <>
            <p className="mb-5 text-sm text-muted">{t('products.count', { n: visible.length })}</p>
            <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {visible.map((p) => <li key={p.id}><ProductCard product={p} /></li>)}
            </ul>
          </>
        )}
      </Container>
    </>
  );
}
