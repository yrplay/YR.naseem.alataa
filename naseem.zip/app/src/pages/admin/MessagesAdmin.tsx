import { useEffect, useState } from 'react';
import { collection, orderBy, query } from 'firebase/firestore';
import { Inbox, Mail, MessageCircle, Trash2 } from 'lucide-react';
import { db } from '../../lib/firebase';
import { useAuth } from '../../lib/auth';
import { useI18n } from '../../lib/i18n';
import { useLive } from '../../lib/data';
import { deleteMessage, setMessageRead } from '../../lib/api';
import { cn, formatDate, waLink } from '../../lib/utils';
import type { Message } from '../../lib/types';
import { Button, ConfirmDialog, EmptyState, Spinner, useToast } from '../../components/ui';
import { PageTitle } from '../../admin/AdminLayout';

export default function MessagesAdmin() {
  const { t, lang } = useI18n();
  const toast = useToast();
  const { can } = useAuth();
  const manage = can('messages:manage');
  const { data, loading, failed } = useLive<Omit<Message, 'id'>>(query(collection(db, 'messages'), orderBy('createdAt', 'desc')), []);
  const [selectedId, setSelectedId] = useState('');
  const [removing, setRemoving] = useState<Message | null>(null);
  const selected = (data as Message[]).find((m) => m.id === selectedId) ?? null;

  useEffect(() => {
    if (selected && !selected.read && manage) void setMessageRead(selected.id, true).catch(() => undefined);
  }, [selected, manage]);

  if (loading) return <Spinner />;
  return (
    <>
      <PageTitle title={t('admin.nav.messages')} text={t('messages.text', { n: data.filter((m) => !m.read).length })} />
      {failed || data.length === 0 ? (
        <div className="rounded-[8px] border border-line bg-white"><EmptyState icon={<Inbox className="size-10" aria-hidden />} title={t('messages.emptyTitle')} text={t('messages.emptyText')} /></div>
      ) : (
        <div className="grid gap-4 lg:grid-cols-[minmax(0,380px)_1fr]">
          <ul className="max-h-[70dvh] divide-y divide-line overflow-y-auto rounded-[8px] border border-line bg-white">
            {(data as Message[]).map((m) => (
              <li key={m.id}>
                <button onClick={() => setSelectedId(m.id)} className={cn('block w-full px-4 py-3.5 text-start hover:bg-mist', selectedId === m.id && 'bg-tint')}>
                  <div className="flex items-center justify-between gap-2">
                    <span className={cn('truncate', m.read ? 'text-ink' : 'font-semibold text-pine')}>{!m.read && <span aria-label={t('messages.unread')} className="me-2 inline-block size-2 rounded-full bg-sand align-middle" />}{m.name}</span>
                    <span className="shrink-0 text-xs text-muted">{formatDate(m.createdAt, lang)}</span>
                  </div>
                  <p className="mt-0.5 truncate text-sm text-muted">{m.subject || m.message}</p>
                </button>
              </li>
            ))}
          </ul>
          <section className="rounded-[8px] border border-line bg-white p-6">
            {!selected ? <p className="py-16 text-center text-sm text-muted">{t('messages.select')}</p> : (
              <>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <h2 className="text-xl font-semibold text-pine">{selected.subject || t('messages.noSubject')}</h2>
                    <p className="mt-1 text-sm text-muted">{selected.name} · <span dir="ltr">{selected.email}</span>{selected.phone && <> · <span dir="ltr">{selected.phone}</span></>}</p>
                    <p className="text-xs text-muted">{formatDate(selected.createdAt, lang)}</p>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <a href={`mailto:${selected.email}?subject=${encodeURIComponent('Re: ' + selected.subject)}`}><Button size="sm" variant="outline"><Mail className="size-4" aria-hidden />{t('messages.reply')}</Button></a>
                    {selected.phone && <a href={waLink(selected.phone)} target="_blank" rel="noopener noreferrer"><Button size="sm" variant="outline"><MessageCircle className="size-4" aria-hidden />{t('contact.whatsapp')}</Button></a>}
                    {manage && <Button size="sm" variant="ghost" className="!text-danger" onClick={() => setRemoving(selected)} aria-label={t('common.delete')}><Trash2 className="size-4" /></Button>}
                  </div>
                </div>
                <p className="mt-6 whitespace-pre-wrap leading-8 text-ink/90">{selected.message}</p>
              </>
            )}
          </section>
        </div>
      )}
      <ConfirmDialog open={!!removing} onClose={() => setRemoving(null)} title={t('messages.deleteTitle')} text={t('messages.deleteText')} confirmLabel={t('common.delete')}
        onConfirm={async () => { if (removing) { try { await deleteMessage(removing.id, removing.email); setSelectedId(''); toast('ok', t('common.deleted')); } catch { toast('error', t('common.saveFailed')); } } }} />
    </>
  );
}
