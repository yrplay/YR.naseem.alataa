import { useState } from 'react';
import { Link } from 'react-router-dom';
import { collection, limit, orderBy, query, where } from 'firebase/firestore';
import { Boxes, Download, FileText, Inbox, Tags } from 'lucide-react';
import { db } from '../../lib/firebase';
import { useAuth } from '../../lib/auth';
import { useI18n } from '../../lib/i18n';
import { useLive, useSite } from '../../lib/data';
import { importInitialContent } from '../../lib/api';
import { formatDate } from '../../lib/utils';
import type { AuditEntry, Message } from '../../lib/types';
import { Button, useToast } from '../../components/ui';
import { PageTitle } from '../../admin/AdminLayout';

export default function Dashboard() {
  const { t, lang } = useI18n();
  const toast = useToast();
  const { can, profile, user } = useAuth();
  const { products, categories, isBlank, loaded } = useSite();
  const [importing, setImporting] = useState(false);

  const unread = useLive<Message>(can('messages:view') ? query(collection(db, 'messages'), where('read', '==', false)) : null, [can('messages:view')]);
  const recent = useLive<AuditEntry>(can('audit:view') ? query(collection(db, 'audit'), orderBy('at', 'desc'), limit(8)) : null, [can('audit:view')]);

  const stats = [
    can('products:view') && { label: t('admin.nav.products'), value: products.length, hint: t('dash.activeCount', { n: products.filter((p) => p.active).length }), to: '/admin/products', icon: Boxes },
    can('categories:view') && { label: t('admin.nav.categories'), value: categories.length, hint: '', to: '/admin/categories', icon: Tags },
    can('messages:view') && { label: t('dash.unread'), value: unread.data.length, hint: '', to: '/admin/messages', icon: Inbox },
  ].filter(Boolean) as Array<{ label: string; value: number; hint: string; to: string; icon: typeof Boxes }>;

  const runImport = async () => {
    setImporting(true);
    try { await importInitialContent(); toast('ok', t('dash.imported')); }
    catch { toast('error', t('common.saveFailed')); }
    finally { setImporting(false); }
  };

  return (
    <>
      <PageTitle title={t('dash.welcome', { name: (profile?.name || user?.displayName || '').split(' ')[0] })} text={t('dash.subtitle')} />

      {loaded && isBlank && can('content:edit') && can('categories:create') && (
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-[8px] border border-sand/50 bg-[#f6ecd9] p-5">
          <div>
            <h2 className="font-semibold text-pine">{t('dash.importTitle')}</h2>
            <p className="mt-1 max-w-2xl text-sm text-ink/75">{t('dash.importText')}</p>
          </div>
          <Button variant="accent" loading={importing} onClick={() => void runImport()}><Download className="size-4" aria-hidden />{t('dash.importAction')}</Button>
        </div>
      )}

      {stats.length > 0 && (
        <ul className="mb-8 grid gap-4 sm:grid-cols-3">
          {stats.map(({ label, value, hint, to, icon: Icon }) => (
            <li key={to}>
              <Link to={to} className="group relative block overflow-hidden rounded-[8px] border border-line bg-white p-5 hover:border-teal">
                <span aria-hidden className="absolute -end-4 top-0 h-full w-12 -skew-x-[16deg] bg-tint group-hover:bg-sand/40" />
                <Icon className="relative size-5 text-teal" aria-hidden />
                <p className="relative mt-3 font-display text-4xl font-semibold text-pine">{value}</p>
                <p className="relative text-sm text-muted">{label}{hint && ` · ${hint}`}</p>
              </Link>
            </li>
          ))}
        </ul>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="rounded-[8px] border border-line bg-white p-5">
          <h2 className="mb-4 font-semibold text-pine">{t('dash.quick')}</h2>
          <div className="flex flex-wrap gap-2">
            {can('products:create') && <Link to="/admin/products?new=1"><Button variant="outline"><Boxes className="size-4" aria-hidden />{t('products.add')}</Button></Link>}
            {can('categories:create') && <Link to="/admin/categories?new=1"><Button variant="outline"><Tags className="size-4" aria-hidden />{t('categories.add')}</Button></Link>}
            {can('content:edit') && <Link to="/admin/content"><Button variant="outline"><FileText className="size-4" aria-hidden />{t('admin.nav.content')}</Button></Link>}
          </div>
        </section>
        {can('audit:view') && (
          <section className="rounded-[8px] border border-line bg-white p-5">
            <h2 className="mb-4 font-semibold text-pine">{t('admin.nav.activity')}</h2>
            {recent.data.length === 0 ? <p className="text-sm text-muted">{t('activity.empty')}</p> : (
              <ul className="divide-y divide-line text-sm">
                {recent.data.map((e) => (
                  <li key={e.id} className="flex flex-wrap justify-between gap-2 py-2">
                    <span><b className="font-medium">{e.actorName}</b> · {e.action} · <span className="text-muted">{e.target}</span></span>
                    <span className="text-xs text-muted">{formatDate(e.at, lang)}</span>
                  </li>
                ))}
              </ul>
            )}
          </section>
        )}
      </div>
    </>
  );
}
