import { useState, type FormEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Pencil, Plus, Tags, Trash2 } from 'lucide-react';
import { useAuth } from '../../lib/auth';
import { useI18n } from '../../lib/i18n';
import { useSite } from '../../lib/data';
import { deleteCategory, saveCategory, setCategoryActive } from '../../lib/api';
import { emptyL, type Category } from '../../lib/types';
import { Button, ConfirmDialog, EmptyState, Field, ImageField, Input, LField, Modal, Spinner, Switch, useToast } from '../../components/ui';
import { PageTitle } from '../../admin/AdminLayout';

function CategoryForm({ cat, nextOrder, onClose }: { cat: Category | null; nextOrder: number; onClose: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [d, setD] = useState({ title: cat?.title ?? emptyL(), description: cat?.description ?? emptyL(), order: cat?.order ?? nextOrder, active: cat?.active ?? true, thumb: cat?.thumb ?? '' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!d.title.ar.trim() && !d.title.en.trim()) { setError(t('products.errTitle')); return; }
    setSaving(true);
    try {
      const { thumb, ...rest } = d;
      await saveCategory({ ...rest, ...(thumb ? { thumb } : {}) }, cat?.id);
      toast('ok', t('common.saved'));
      onClose();
    } catch { setError(t('common.saveFailed')); } finally { setSaving(false); }
  };
  return (
    <Modal open onClose={onClose} title={cat ? t('categories.edit') : t('categories.add')}
      footer={<><Button variant="outline" onClick={onClose}>{t('common.cancel')}</Button><Button type="submit" form="cat-form" loading={saving}>{t('common.save')}</Button></>}>
      <form id="cat-form" onSubmit={submit} className="space-y-5">
        <LField label={t('products.name')} value={d.title} onChange={(title) => setD({ ...d, title })} max={120} required />
        <LField label={t('products.description')} value={d.description} onChange={(description) => setD({ ...d, description })} multiline max={600} />
        <ImageField label={t('categories.image')} value={d.thumb} onChange={(thumb) => setD({ ...d, thumb })} maxSide={640} maxChars={60000} hint={t('categories.imageHint')} />
        <div className="flex flex-wrap items-end gap-8">
          <Field label={t('categories.order')} className="w-28"><Input type="number" dir="ltr" value={d.order} onChange={(e) => setD({ ...d, order: Number(e.target.value) || 0 })} /></Field>
          <Switch checked={d.active} onChange={(active) => setD({ ...d, active })} label={t('products.visible')} />
        </div>
        {error && <p role="alert" className="text-sm font-medium text-danger">{error}</p>}
      </form>
    </Modal>
  );
}

export default function CategoriesAdmin() {
  const { t, tr } = useI18n();
  const toast = useToast();
  const { can } = useAuth();
  const { categories, products, catalogLoading } = useSite();
  const [params, setParams] = useSearchParams();
  const [editing, setEditing] = useState<Category | 'new' | null>(params.get('new') && can('categories:create') ? 'new' : null);
  const [removing, setRemoving] = useState<Category | null>(null);
  const close = () => { setEditing(null); if (params.has('new')) setParams({}, { replace: true }); };
  const nextOrder = (categories.reduce((m, c) => Math.max(m, c.order ?? 0), 0) || 0) + 1;
  const used = (c: Category) => products.filter((p) => p.categoryId === c.id).length;

  return (
    <>
      <PageTitle title={t('admin.nav.categories')} text={t('categories.adminText')}
        action={can('categories:create') && <Button onClick={() => setEditing('new')}><Plus className="size-4" aria-hidden />{t('categories.add')}</Button>} />
      <div className="overflow-hidden rounded-[8px] border border-line bg-white">
        {catalogLoading ? <Spinner /> : categories.length === 0 ? (
          <EmptyState icon={<Tags className="size-10" aria-hidden />} title={t('categories.emptyTitle')} text={t('categories.emptyText')}
            action={can('categories:create') ? <Button onClick={() => setEditing('new')}><Plus className="size-4" aria-hidden />{t('categories.add')}</Button> : undefined} />
        ) : (
          <ul className="divide-y divide-line">
            {categories.map((c) => (
              <li key={c.id} className="flex flex-wrap items-center gap-4 px-5 py-4">
                <span className="w-8 text-center font-display text-sm text-muted" dir="ltr">{c.order}</span>
                <div className="min-w-0 flex-1">
                  <p className="font-semibold text-pine">{tr(c.title)}</p>
                  <p className="line-clamp-1 text-sm text-muted">{tr(c.description)}</p>
                </div>
                <span className="text-xs text-muted">{t('categories.productCount', { n: used(c) })}</span>
                <Switch checked={c.active} disabled={!can('categories:edit')} label={c.active ? t('common.visible') : t('common.hidden')}
                  onChange={(v) => void setCategoryActive(c.id, v, tr(c.title)).catch(() => toast('error', t('common.saveFailed')))} />
                <div className="flex gap-1">
                  {can('categories:edit') && <Button size="sm" variant="ghost" onClick={() => setEditing(c)} aria-label={t('common.edit')}><Pencil className="size-4" /></Button>}
                  {can('categories:delete') && <Button size="sm" variant="ghost" className="!text-danger" onClick={() => setRemoving(c)} aria-label={t('common.delete')}><Trash2 className="size-4" /></Button>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
      {editing && <CategoryForm key={editing === 'new' ? 'new' : editing.id} cat={editing === 'new' ? null : editing} nextOrder={nextOrder} onClose={close} />}
      <ConfirmDialog open={!!removing} onClose={() => setRemoving(null)} title={t('categories.deleteTitle')}
        text={removing && used(removing) ? t('categories.deleteUsed', { name: tr(removing.title), n: used(removing) }) : t('categories.deleteText', { name: tr(removing?.title) })}
        confirmLabel={t('common.delete')}
        onConfirm={async () => { if (removing) { try { await deleteCategory(removing); toast('ok', t('common.deleted')); } catch { toast('error', t('common.saveFailed')); } } }} />
    </>
  );
}
