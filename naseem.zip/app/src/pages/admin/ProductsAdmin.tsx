import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Boxes, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { useAuth } from '../../lib/auth';
import { useI18n } from '../../lib/i18n';
import { useSite } from '../../lib/data';
import { deleteProduct, loadProductImages, saveProduct, setProductActive } from '../../lib/api';
import { dataUrlToThumb, formatPrice } from '../../lib/utils';
import { emptyL, type Product } from '../../lib/types';
import { Badge, Button, ConfirmDialog, EmptyState, Field, GalleryField, Input, LField, Modal, Select, Spinner, Switch, useToast } from '../../components/ui';
import { LogoPlaceholder } from '../../components/site/parts';
import { PageTitle } from '../../admin/AdminLayout';

type Draft = Omit<Product, 'id' | 'createdAt' | 'updatedAt' | 'thumb'> & { priceText: string };
const blank = (): Draft => ({ title: emptyL(), description: emptyL(), categoryId: '', price: null, priceText: '', sku: '', featured: false, active: true });

function ProductForm({ product, onClose }: { product: Product | null; onClose: () => void }) {
  const { t, tr } = useI18n();
  const toast = useToast();
  const { categories } = useSite();
  const [draft, setDraft] = useState<Draft>(() => product ? { ...product, priceText: product.price == null ? '' : String(product.price), sku: product.sku ?? '' } : blank());
  const [images, setImages] = useState<string[]>([]);
  const [loadingImages, setLoadingImages] = useState(!!product);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!product) return;
    let alive = true;
    void loadProductImages(product.id).then((imgs) => { if (alive) { setImages(imgs.length ? imgs : product.thumb ? [product.thumb] : []); setLoadingImages(false); } });
    return () => { alive = false; };
  }, [product]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!draft.title.ar.trim() && !draft.title.en.trim()) { setError(t('products.errTitle')); return; }
    const price = draft.priceText.trim() === '' ? null : Number(draft.priceText);
    if (price != null && (!Number.isFinite(price) || price < 0)) { setError(t('products.errPrice')); return; }
    setSaving(true);
    setError('');
    try {
      const thumb = images[0] ? await dataUrlToThumb(images[0]) : undefined;
      const { priceText: _p, ...rest } = draft;
      void _p;
      await saveProduct(
        { ...rest, price, sku: rest.sku?.trim() || undefined, thumb },
        { id: product?.id, createdAt: product?.createdAt, images },
      );
      toast('ok', t('common.saved'));
      onClose();
    } catch { setError(t('common.saveFailed')); }
    finally { setSaving(false); }
  };

  return (
    <Modal open onClose={onClose} wide title={product ? t('products.edit') : t('products.add')}
      footer={<><Button variant="outline" onClick={onClose}>{t('common.cancel')}</Button><Button type="submit" form="product-form" loading={saving}>{t('common.save')}</Button></>}>
      <form id="product-form" onSubmit={submit} className="space-y-5">
        <LField label={t('products.name')} value={draft.title} onChange={(title) => setDraft({ ...draft, title })} max={160} required />
        <LField label={t('products.description')} value={draft.description} onChange={(description) => setDraft({ ...draft, description })} multiline rows={4} max={3000} />
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label={t('products.category')}>
            <Select value={draft.categoryId} onChange={(e) => setDraft({ ...draft, categoryId: e.target.value })}>
              <option value="">{t('products.uncategorized')}</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{tr(c.title)}</option>)}
            </Select>
          </Field>
          <Field label={t('products.price')} hint={t('products.priceHint')}><Input type="number" inputMode="decimal" min={0} step="0.01" dir="ltr" value={draft.priceText} onChange={(e) => setDraft({ ...draft, priceText: e.target.value })} /></Field>
          <Field label="SKU"><Input dir="ltr" maxLength={60} value={draft.sku} onChange={(e) => setDraft({ ...draft, sku: e.target.value })} /></Field>
        </div>
        {loadingImages ? <Spinner /> : <GalleryField label={t('products.images')} images={images} onChange={setImages} />}
        <div className="flex flex-wrap gap-8">
          <Switch checked={draft.active} onChange={(active) => setDraft({ ...draft, active })} label={t('products.visible')} />
          <Switch checked={draft.featured} onChange={(featured) => setDraft({ ...draft, featured })} label={t('products.featured')} />
        </div>
        {error && <p role="alert" className="text-sm font-medium text-danger">{error}</p>}
      </form>
    </Modal>
  );
}

export default function ProductsAdmin() {
  const { t, tr, lang } = useI18n();
  const toast = useToast();
  const { can } = useAuth();
  const { products, categories, catalogLoading } = useSite();
  const [params, setParams] = useSearchParams();
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [editing, setEditing] = useState<Product | 'new' | null>(params.get('new') && can('products:create') ? 'new' : null);
  const [removing, setRemoving] = useState<Product | null>(null);

  const rows = useMemo(() => products.filter((p) => (!cat || p.categoryId === cat) && (!q || `${p.title.ar} ${p.title.en} ${p.sku ?? ''}`.toLowerCase().includes(q.toLowerCase()))), [products, cat, q]);
  const close = () => { setEditing(null); if (params.has('new')) setParams({}, { replace: true }); };

  return (
    <>
      <PageTitle title={t('admin.nav.products')} text={t('products.adminText', { n: products.length })}
        action={can('products:create') && <Button onClick={() => setEditing('new')}><Plus className="size-4" aria-hidden />{t('products.add')}</Button>} />

      <div className="mb-4 flex flex-wrap gap-3">
        <label className="relative min-w-60 flex-1 sm:max-w-xs">
          <span className="sr-only">{t('common.search')}</span>
          <Search className="pointer-events-none absolute start-3 top-1/2 size-4 -translate-y-1/2 text-muted" aria-hidden />
          <Input className="ps-9" placeholder={t('common.search')} value={q} onChange={(e) => setQ(e.target.value)} />
        </label>
        <Select className="!w-auto min-w-48" value={cat} onChange={(e) => setCat(e.target.value)} aria-label={t('products.category')}>
          <option value="">{t('products.all')}</option>
          {categories.map((c) => <option key={c.id} value={c.id}>{tr(c.title)}</option>)}
        </Select>
      </div>

      <div className="overflow-hidden rounded-[8px] border border-line bg-white">
        {catalogLoading ? <Spinner /> : rows.length === 0 ? (
          <EmptyState icon={<Boxes className="size-10" aria-hidden />} title={products.length ? t('products.noMatchTitle') : t('products.emptyTitle')}
            text={products.length ? t('products.noMatchText') : t('products.adminEmptyText')}
            action={!products.length && can('products:create') ? <Button onClick={() => setEditing('new')}><Plus className="size-4" aria-hidden />{t('products.add')}</Button> : undefined} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-start text-sm">
              <thead className="border-b border-line bg-mist text-xs text-muted">
                <tr>{[t('products.name'), t('products.category'), t('products.price'), t('common.status'), ''].map((h, i) => <th key={i} className="px-4 py-3 text-start font-medium">{h}</th>)}</tr>
              </thead>
              <tbody className="divide-y divide-line">
                {rows.map((p) => (
                  <tr key={p.id} className="hover:bg-mist/60">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="size-12 shrink-0 overflow-hidden rounded-[4px] border border-line">{p.thumb ? <img src={p.thumb} alt="" className="size-full object-cover" /> : <LogoPlaceholder />}</div>
                        <div>
                          <p className="font-medium text-pine">{tr(p.title)}</p>
                          {p.featured && <Badge tone="warn">{t('products.featuredBadge')}</Badge>}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-muted">{tr(categories.find((c) => c.id === p.categoryId)?.title) || '—'}</td>
                    <td className="px-4 py-3">{formatPrice(p.price, lang) || '—'}</td>
                    <td className="px-4 py-3">
                      <Switch checked={p.active} disabled={!can('products:edit')} label={p.active ? t('common.visible') : t('common.hidden')}
                        onChange={(v) => void setProductActive(p.id, v, tr(p.title)).catch(() => toast('error', t('common.saveFailed')))} />
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        {can('products:edit') && <Button size="sm" variant="ghost" onClick={() => setEditing(p)} aria-label={t('common.edit')}><Pencil className="size-4" /></Button>}
                        {can('products:delete') && <Button size="sm" variant="ghost" className="!text-danger" onClick={() => setRemoving(p)} aria-label={t('common.delete')}><Trash2 className="size-4" /></Button>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {editing && <ProductForm key={editing === 'new' ? 'new' : editing.id} product={editing === 'new' ? null : editing} onClose={close} />}
      <ConfirmDialog open={!!removing} onClose={() => setRemoving(null)} title={t('products.deleteTitle')} text={t('products.deleteText', { name: tr(removing?.title) })} confirmLabel={t('common.delete')}
        onConfirm={async () => { if (removing) { try { await deleteProduct(removing); toast('ok', t('common.deleted')); } catch { toast('error', t('common.saveFailed')); } } }} />
    </>
  );
}
