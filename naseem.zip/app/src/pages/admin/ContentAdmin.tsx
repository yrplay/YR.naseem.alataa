import { useEffect, useState, type FormEvent } from 'react';
import { ArrowDown, ArrowUp, FilePlus2, Pencil, Plus, Trash2 } from 'lucide-react';
import { useAuth } from '../../lib/auth';
import { useI18n } from '../../lib/i18n';
import { useSite } from '../../lib/data';
import { deletePage, savePage, saveSettings } from '../../lib/api';
import { cn, extractMapUrl, isValidSlug, slugify, uid } from '../../lib/utils';
import { emptyL, type Item, type PageDoc, type SiteSettings } from '../../lib/types';
import { Button, ConfirmDialog, EmptyState, Field, ImageField, Input, LField, Modal, Spinner, Switch, useToast } from '../../components/ui';
import { PageTitle } from '../../admin/AdminLayout';

type Tab = 'company' | 'home' | 'about' | 'lists' | 'pages';
const stripMeta = ({ updatedAt: _a, updatedBy: _b, ...rest }: SiteSettings) => { void _a; void _b; return rest; };

function ListEditor({ items, onChange, addLabel, prefix }: { items: Item[]; onChange: (v: Item[]) => void; addLabel: string; prefix: string }) {
  const { t } = useI18n();
  const move = (i: number, d: number) => {
    const next = [...items];
    const j = i + d;
    if (j < 0 || j >= next.length) return;
    [next[i], next[j]] = [next[j], next[i]];
    onChange(next);
  };
  return (
    <div className="space-y-4">
      {items.map((it, i) => (
        <div key={it.id} className="rounded-[6px] border border-line bg-mist/50 p-4">
          <div className="mb-3 flex items-center justify-end gap-1">
            <Button type="button" size="sm" variant="ghost" onClick={() => move(i, -1)} disabled={i === 0} aria-label={t('common.moveUp')}><ArrowUp className="size-4" /></Button>
            <Button type="button" size="sm" variant="ghost" onClick={() => move(i, 1)} disabled={i === items.length - 1} aria-label={t('common.moveDown')}><ArrowDown className="size-4" /></Button>
            <Button type="button" size="sm" variant="ghost" className="!text-danger" onClick={() => onChange(items.filter((x) => x.id !== it.id))} aria-label={t('common.delete')}><Trash2 className="size-4" /></Button>
          </div>
          <div className="space-y-3">
            <LField label={t('products.name')} value={it.title} max={120} onChange={(title) => onChange(items.map((x) => x.id === it.id ? { ...x, title } : x))} />
            <LField label={t('products.description')} value={it.text} multiline rows={2} max={400} onChange={(text) => onChange(items.map((x) => x.id === it.id ? { ...x, text } : x))} />
          </div>
        </div>
      ))}
      <Button type="button" variant="outline" onClick={() => onChange([...items, { id: `${prefix}-${uid()}`, title: emptyL(), text: emptyL() }])}><Plus className="size-4" aria-hidden />{addLabel}</Button>
    </div>
  );
}

function PageForm({ page, existingIds, onClose }: { page: PageDoc | null; existingIds: string[]; onClose: () => void }) {
  const { t } = useI18n();
  const toast = useToast();
  const [d, setD] = useState<PageDoc>(page ?? { id: '', title: emptyL(), body: emptyL(), published: true });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const id = page ? page.id : (d.id || slugify(d.title.en));
    if (!isValidSlug(id)) { setError(t('pages.errSlug')); return; }
    if (!page && existingIds.includes(id)) { setError(t('pages.errExists')); return; }
    if (!d.title.ar.trim() && !d.title.en.trim()) { setError(t('products.errTitle')); return; }
    setSaving(true);
    try { await savePage({ ...d, id }); toast('ok', t('common.saved')); onClose(); }
    catch { setError(t('common.saveFailed')); } finally { setSaving(false); }
  };
  return (
    <Modal open onClose={onClose} wide title={page ? t('pages.edit') : t('pages.add')}
      footer={<><Button variant="outline" onClick={onClose}>{t('common.cancel')}</Button><Button type="submit" form="page-form" loading={saving}>{t('common.save')}</Button></>}>
      <form id="page-form" onSubmit={submit} className="space-y-5">
        {!page && <Field label={t('pages.slug')} hint={t('pages.slugHint')}><Input dir="ltr" value={d.id} placeholder="privacy-policy" onChange={(e) => setD({ ...d, id: e.target.value.toLowerCase() })} /></Field>}
        <LField label={t('pages.titleLabel')} value={d.title} onChange={(title) => setD({ ...d, title })} max={160} required />
        <LField label={t('pages.body')} value={d.body} onChange={(body) => setD({ ...d, body })} multiline rows={10} max={30000} />
        <Switch checked={d.published} onChange={(published) => setD({ ...d, published })} label={t('pages.published')} />
        {error && <p role="alert" className="text-sm font-medium text-danger">{error}</p>}
      </form>
    </Modal>
  );
}

export default function ContentAdmin() {
  const { t, tr } = useI18n();
  const toast = useToast();
  const { can } = useAuth();
  const { settings, loaded, pages } = useSite();
  const canEdit = can('content:edit');
  const [tab, setTab] = useState<Tab>('company');
  const [draft, setDraft] = useState<Omit<SiteSettings, 'updatedAt' | 'updatedBy'>>(() => stripMeta(settings));
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [mapError, setMapError] = useState(false);
  const [editingPage, setEditingPage] = useState<PageDoc | 'new' | null>(null);
  const [removing, setRemoving] = useState<PageDoc | null>(null);

  useEffect(() => { if (loaded && !dirty) setDraft(stripMeta(settings)); }, [settings, loaded, dirty]);
  const patch = (fn: (d: typeof draft) => typeof draft) => { setDraft(fn); setDirty(true); };

  const save = async () => {
    setSaving(true);
    try { await saveSettings(draft); setDirty(false); toast('ok', t('common.saved')); }
    catch { toast('error', t('common.saveFailed')); } finally { setSaving(false); }
  };

  const tabs: Array<[Tab, string]> = [['company', t('content.company')], ['home', t('content.home')], ['about', t('content.about')], ['lists', t('content.lists')], ['pages', t('content.pages')]];
  if (!loaded) return <Spinner />;
  const c = draft.company;

  return (
    <>
      <PageTitle title={t('admin.nav.content')} text={canEdit ? t('content.text') : t('content.readOnly')}
        action={tab !== 'pages' && canEdit && <Button onClick={() => void save()} loading={saving} disabled={!dirty}>{dirty ? t('common.saveChanges') : t('common.saved')}</Button>} />

      <div role="tablist" className="mb-6 flex flex-wrap gap-2">
        {tabs.map(([k, label]) => (
          <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)}
            className={cn('slant-tab px-5 py-2 text-sm font-medium', tab === k ? 'bg-pine text-white' : 'bg-white hover:bg-tint')}>{label}</button>
        ))}
      </div>

      {tab !== 'pages' ? (
        <fieldset disabled={!canEdit} className="space-y-6 rounded-[8px] border border-line bg-white p-5 md:p-7">
          {tab === 'company' && (
            <>
              <LField label={t('content.companyName')} value={c.name} onChange={(name) => patch((d) => ({ ...d, company: { ...d.company, name } }))} max={120} />
              <LField label={t('contact.address')} value={c.address} onChange={(address) => patch((d) => ({ ...d, company: { ...d.company, address } }))} max={200} />
              <div className="grid gap-4 sm:grid-cols-3">
                <Field label={t('contact.phone')}><Input dir="ltr" value={c.phone} onChange={(e) => patch((d) => ({ ...d, company: { ...d.company, phone: e.target.value } }))} /></Field>
                <Field label={t('contact.whatsapp')} hint={t('content.whatsappHint')}><Input dir="ltr" value={c.whatsapp} onChange={(e) => patch((d) => ({ ...d, company: { ...d.company, whatsapp: e.target.value } }))} /></Field>
                <Field label={t('contact.email')}><Input type="email" dir="ltr" value={c.email} onChange={(e) => patch((d) => ({ ...d, company: { ...d.company, email: e.target.value } }))} /></Field>
              </div>
              <Field label={t('content.map')} hint={t('content.mapHint')} error={mapError ? t('content.mapError') : undefined}>
                <Input dir="ltr" value={c.mapUrl} onChange={(e) => { const raw = e.target.value; const url = extractMapUrl(raw); setMapError(!!raw.trim() && !url); patch((d) => ({ ...d, company: { ...d.company, mapUrl: url || raw } })); }} />
              </Field>
              <div>
                <h3 className="mb-3 text-sm font-medium">{t('content.social')}</h3>
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {(Object.keys(c.social) as Array<keyof typeof c.social>).map((k) => (
                    <Field key={k} label={k === 'x' ? 'X' : k.charAt(0).toUpperCase() + k.slice(1)}>
                      <Input dir="ltr" type="url" placeholder="https://" value={c.social[k]} onChange={(e) => patch((d) => ({ ...d, company: { ...d.company, social: { ...d.company.social, [k]: e.target.value } } }))} />
                    </Field>
                  ))}
                </div>
              </div>
            </>
          )}
          {tab === 'home' && (
            <>
              <LField label={t('content.heroTitle')} value={draft.hero.title} max={120} onChange={(title) => patch((d) => ({ ...d, hero: { ...d.hero, title } }))} />
              <LField label={t('content.heroSubtitle')} value={draft.hero.subtitle} multiline max={300} onChange={(subtitle) => patch((d) => ({ ...d, hero: { ...d.hero, subtitle } }))} />
              <ImageField label={t('content.heroImage')} hint={t('content.heroImageHint')} value={draft.hero.image} maxSide={1400} maxChars={260000} onChange={(image) => patch((d) => ({ ...d, hero: { ...d.hero, image } }))} />
            </>
          )}
          {tab === 'about' && (
            <>
              <LField label={t('content.aboutIntro')} value={draft.about.intro} multiline rows={8} max={6000} onChange={(intro) => patch((d) => ({ ...d, about: { ...d.about, intro } }))} />
              <LField label={t('about.vision')} value={draft.about.vision} multiline max={600} onChange={(vision) => patch((d) => ({ ...d, about: { ...d.about, vision } }))} />
              <LField label={t('about.mission')} value={draft.about.mission} multiline max={800} onChange={(mission) => patch((d) => ({ ...d, about: { ...d.about, mission } }))} />
              <LField label={t('about.values')} value={draft.about.values} multiline rows={5} max={800} onChange={(values) => patch((d) => ({ ...d, about: { ...d.about, values } }))} />
              <p className="-mt-3 text-xs text-muted">{t('content.valuesHint')}</p>
              <ImageField label={t('content.aboutImage')} value={draft.about.image} maxSide={1200} maxChars={260000} onChange={(image) => patch((d) => ({ ...d, about: { ...d.about, image } }))} />
            </>
          )}
          {tab === 'lists' && (
            <>
              <section><h2 className="mb-4 text-lg font-semibold text-pine">{t('home.servicesTitle')}</h2><ListEditor prefix="svc" items={draft.services} addLabel={t('content.addService')} onChange={(services) => patch((d) => ({ ...d, services }))} /></section>
              <section><h2 className="mb-4 text-lg font-semibold text-pine">{t('home.sectorsTitle')}</h2><ListEditor prefix="sec" items={draft.sectors} addLabel={t('content.addSector')} onChange={(sectors) => patch((d) => ({ ...d, sectors }))} /></section>
            </>
          )}
        </fieldset>
      ) : (
        <div className="rounded-[8px] border border-line bg-white">
          <div className="flex items-center justify-between border-b border-line px-5 py-4">
            <p className="text-sm text-muted">{t('pages.text')}</p>
            {canEdit && <Button onClick={() => setEditingPage('new')}><FilePlus2 className="size-4" aria-hidden />{t('pages.add')}</Button>}
          </div>
          {pages.length === 0 ? <EmptyState title={t('pages.emptyTitle')} text={t('pages.emptyText')} /> : (
            <ul className="divide-y divide-line">
              {pages.map((p) => (
                <li key={p.id} className="flex flex-wrap items-center gap-3 px-5 py-4">
                  <div className="min-w-0 flex-1"><p className="font-semibold text-pine">{tr(p.title)}</p><p className="text-xs text-muted" dir="ltr">/p/{p.id}</p></div>
                  <span className={cn('rounded px-2 py-0.5 text-xs', p.published ? 'bg-[#d8efe2] text-[#1d6b45]' : 'bg-tint text-muted')}>{p.published ? t('pages.published') : t('pages.draft')}</span>
                  {canEdit && <><Button size="sm" variant="ghost" onClick={() => setEditingPage(p)} aria-label={t('common.edit')}><Pencil className="size-4" /></Button>
                  <Button size="sm" variant="ghost" className="!text-danger" onClick={() => setRemoving(p)} aria-label={t('common.delete')}><Trash2 className="size-4" /></Button></>}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
      {editingPage && <PageForm key={editingPage === 'new' ? 'new' : editingPage.id} page={editingPage === 'new' ? null : editingPage} existingIds={pages.map((p) => p.id)} onClose={() => setEditingPage(null)} />}
      <ConfirmDialog open={!!removing} onClose={() => setRemoving(null)} title={t('pages.deleteTitle')} text={t('pages.deleteText', { name: tr(removing?.title) })} confirmLabel={t('common.delete')}
        onConfirm={async () => { if (removing) { try { await deletePage(removing.id); toast('ok', t('common.deleted')); } catch { toast('error', t('common.saveFailed')); } } }} />
    </>
  );
}
