import { collection, limit, orderBy, query } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useI18n } from '../../lib/i18n';
import { useLive } from '../../lib/data';
import { formatDate } from '../../lib/utils';
import type { AuditEntry } from '../../lib/types';
import { EmptyState, Spinner } from '../../components/ui';
import { PageTitle } from '../../admin/AdminLayout';
import { dict, type DictKey } from '../../lib/dict';

export default function ActivityAdmin() {
  const { t, lang } = useI18n();
  const { data, loading } = useLive<Omit<AuditEntry, 'id'>>(query(collection(db, 'audit'), orderBy('at', 'desc'), limit(150)), []);
  if (loading) return <Spinner />;
  const label = (a: string) => { const k = `act.${a}` as DictKey; return k in dict ? dict[k][lang === 'ar' ? 0 : 1] : a; };
  return (
    <>
      <PageTitle title={t('admin.nav.activity')} text={t('activity.text')} />
      <div className="overflow-hidden rounded-[8px] border border-line bg-white">
        {data.length === 0 ? <EmptyState title={t('activity.empty')} /> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[560px] text-sm">
              <thead className="border-b border-line bg-mist text-xs text-muted"><tr>{[t('activity.when'), t('activity.who'), t('activity.what'), t('activity.target')].map((h) => <th key={h} className="px-4 py-3 text-start font-medium">{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-line">
                {data.map((e) => (
                  <tr key={e.id}>
                    <td className="whitespace-nowrap px-4 py-2.5 text-muted">{formatDate(e.at, lang)}</td>
                    <td className="px-4 py-2.5"><p className="font-medium">{e.actorName}</p><p className="text-xs text-muted" dir="ltr">{e.actor}</p></td>
                    <td className="px-4 py-2.5">{label(e.action)}</td>
                    <td className="px-4 py-2.5 text-muted">{e.target}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}
