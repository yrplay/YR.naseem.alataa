import { useState, type FormEvent } from 'react';
import { collection } from 'firebase/firestore';
import { Info, Pencil, Plus, ShieldCheck, Trash2, Users } from 'lucide-react';
import { db } from '../../lib/firebase';
import { OWNER_EMAIL } from '../../lib/firebase';
import { useAuth } from '../../lib/auth';
import { useI18n } from '../../lib/i18n';
import { useLive } from '../../lib/data';
import { deleteStaff, saveStaff } from '../../lib/api';
import { ACTION_LABELS, PERMISSION_GROUPS, ROLES, normalizePermissions } from '../../lib/permissions';
import { cn, isEmail } from '../../lib/utils';
import type { Role, StaffProfile } from '../../lib/types';
import { Badge, Button, ConfirmDialog, EmptyState, Field, Input, Modal, Select, Spinner, Switch, useToast } from '../../components/ui';
import { PageTitle } from '../../admin/AdminLayout';

function StaffForm({ member, onClose }: { member: StaffProfile | null; onClose: () => void }) {
  const { t, tr, lang } = useI18n();
  const toast = useToast();
  const { can, isOwner } = useAuth();
  const [d, setD] = useState({
    email: member?.email ?? '', name: member?.name ?? '', jobTitle: member?.jobTitle ?? '',
    role: (member?.role ?? 'support') as Role, permissions: member?.permissions ?? ROLES.support.permissions, active: member?.active ?? true,
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  // A manager can only hand out permissions they hold themselves (the server enforces this too).
  const grantable = (p: string) => isOwner || can(p);

  const setRole = (role: Role) => setD((s) => ({ ...s, role, permissions: role === 'custom' ? s.permissions : ROLES[role].permissions.filter(grantable) }));
  const toggle = (p: string, on: boolean) =>
    setD((s) => ({ ...s, role: 'custom', permissions: normalizePermissions(on ? [...s.permissions, p] : s.permissions.filter((x) => x !== p && !(p.endsWith(':view') && x.startsWith(p.split(':')[0] + ':')))) }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!isEmail(d.email.trim())) { setError(t('staff.errEmail')); return; }
    if (d.email.trim().toLowerCase() === OWNER_EMAIL) { setError(t('staff.errOwner')); return; }
    if (!d.name.trim()) { setError(t('staff.errName')); return; }
    if (d.permissions.length === 0) { setError(t('staff.errPerms')); return; }
    setSaving(true);
    try { await saveStaff(d, member ?? undefined); toast('ok', t('common.saved')); onClose(); }
    catch { setError(t('common.saveFailed')); } finally { setSaving(false); }
  };

  return (
    <Modal open onClose={onClose} wide title={member ? t('staff.edit') : t('staff.add')}
      footer={<><Button variant="outline" onClick={onClose}>{t('common.cancel')}</Button><Button type="submit" form="staff-form" loading={saving}>{t('common.save')}</Button></>}>
      <form id="staff-form" onSubmit={submit} className="space-y-5">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label={t('staff.name')}><Input value={d.name} maxLength={80} onChange={(e) => setD({ ...d, name: e.target.value })} /></Field>
          <Field label={t('staff.jobTitle')}><Input value={d.jobTitle} maxLength={80} onChange={(e) => setD({ ...d, jobTitle: e.target.value })} /></Field>
          <Field label={t('staff.email')} hint={t('staff.emailHint')} className="sm:col-span-2"><Input type="email" dir="ltr" disabled={!!member} value={d.email} onChange={(e) => setD({ ...d, email: e.target.value })} /></Field>
        </div>

        <Field label={t('staff.role')} hint={d.role !== 'owner' ? tr(ROLES[d.role].description) : undefined}>
          <Select value={d.role} onChange={(e) => setRole(e.target.value as Role)}>
            {(Object.keys(ROLES) as Role[]).filter((r) => r !== 'owner').map((r) => <option key={r} value={r} disabled={r === 'admin' && !isOwner && !ROLES.admin.permissions.every(grantable)}>{tr(ROLES[r].label)}</option>)}
          </Select>
        </Field>

        <div>
          <h3 className="mb-2 text-sm font-medium">{t('staff.permissions')}</h3>
          <div className="overflow-x-auto rounded-[6px] border border-line">
            <table className="w-full min-w-[480px] text-sm">
              <tbody className="divide-y divide-line">
                {PERMISSION_GROUPS.map((g) => (
                  <tr key={g.key}>
                    <th scope="row" className="bg-mist px-4 py-2.5 text-start font-medium">{g.label[lang]}</th>
                    <td className="px-4 py-2.5">
                      <div className="flex flex-wrap gap-x-5 gap-y-1.5">
                        {g.actions.map((a) => {
                          const p = `${g.key}:${a}`;
                          const on = d.permissions.includes(p);
                          const locked = !grantable(p);
                          return (
                            <label key={p} className={cn('inline-flex items-center gap-2', locked && 'cursor-not-allowed opacity-45')} title={locked ? t('staff.cannotGrant') : undefined}>
                              <input type="checkbox" className="size-4 accent-[#1f7f82]" checked={on} disabled={locked} onChange={(e) => toggle(p, e.target.checked)} />
                              {ACTION_LABELS[a][lang]}
                            </label>
                          );
                        })}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="mt-2 flex items-start gap-1.5 text-xs text-muted"><Info className="mt-0.5 size-3.5 shrink-0" aria-hidden />{t('staff.permsHint')}</p>
        </div>
        <Switch checked={d.active} onChange={(active) => setD({ ...d, active })} label={t('staff.active')} />
        {error && <p role="alert" className="text-sm font-medium text-danger">{error}</p>}
      </form>
    </Modal>
  );
}

export default function StaffAdmin() {
  const { t, tr } = useI18n();
  const toast = useToast();
  const { can, user } = useAuth();
  const { data, loading } = useLive<Omit<StaffProfile, 'email'>>(collection(db, 'staff'), []);
  const [editing, setEditing] = useState<StaffProfile | 'new' | null>(null);
  const [removing, setRemoving] = useState<StaffProfile | null>(null);
  const me = (user?.email || '').toLowerCase();
  const manage = can('staff:manage');
  const rows = (data as unknown as Array<StaffProfile & { id: string }>).map((s) => ({ ...s, email: s.id }));

  if (loading) return <Spinner />;
  return (
    <>
      <PageTitle title={t('admin.nav.staff')} text={t('staff.text')} action={manage && <Button onClick={() => setEditing('new')}><Plus className="size-4" aria-hidden />{t('staff.add')}</Button>} />
      <div className="mb-4 flex gap-3 rounded-[8px] border border-teal/30 bg-[#e3f1ef] p-4 text-sm text-pine"><ShieldCheck className="size-5 shrink-0 text-teal" aria-hidden /><p>{t('staff.howItWorks')}</p></div>
      <div className="overflow-hidden rounded-[8px] border border-line bg-white">
        {rows.length === 0 ? <EmptyState icon={<Users className="size-10" aria-hidden />} title={t('staff.emptyTitle')} text={t('staff.emptyText')} /> : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead className="border-b border-line bg-mist text-xs text-muted"><tr>{[t('staff.name'), t('staff.role'), t('staff.permissions'), t('common.status'), ''].map((h, i) => <th key={i} className="px-4 py-3 text-start font-medium">{h}</th>)}</tr></thead>
              <tbody className="divide-y divide-line">
                {rows.map((s) => {
                  const isOwnerRow = s.email === OWNER_EMAIL;
                  const self = s.email === me;
                  return (
                    <tr key={s.email}>
                      <td className="px-4 py-3"><p className="font-medium text-pine">{s.name}</p><p className="text-xs text-muted" dir="ltr">{s.email}</p>{s.jobTitle && <p className="text-xs text-muted">{s.jobTitle}</p>}</td>
                      <td className="px-4 py-3"><Badge tone={isOwnerRow ? 'brand' : 'neutral'}>{tr(ROLES[isOwnerRow ? 'owner' : s.role]?.label)}</Badge></td>
                      <td className="px-4 py-3 text-muted">{isOwnerRow ? t('staff.all') : t('staff.permCount', { n: s.permissions.length })}</td>
                      <td className="px-4 py-3">{s.active ? <Badge tone="good">{t('staff.activeBadge')}</Badge> : <Badge tone="warn">{t('staff.disabledBadge')}</Badge>}</td>
                      <td className="px-4 py-3">
                        <div className="flex justify-end gap-1">
                          {manage && !isOwnerRow && !self && <Button size="sm" variant="ghost" onClick={() => setEditing(s)} aria-label={t('common.edit')}><Pencil className="size-4" /></Button>}
                          {manage && !isOwnerRow && !self && <Button size="sm" variant="ghost" className="!text-danger" onClick={() => setRemoving(s)} aria-label={t('common.delete')}><Trash2 className="size-4" /></Button>}
                          {self && !isOwnerRow && <span className="text-xs text-muted">{t('staff.you')}</span>}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
      {editing && <StaffForm key={editing === 'new' ? 'new' : editing.email} member={editing === 'new' ? null : editing} onClose={() => setEditing(null)} />}
      <ConfirmDialog open={!!removing} onClose={() => setRemoving(null)} title={t('staff.deleteTitle')} text={t('staff.deleteText', { name: removing?.name ?? '' })} confirmLabel={t('common.delete')}
        onConfirm={async () => { if (removing) { try { await deleteStaff(removing.email); toast('ok', t('common.deleted')); } catch { toast('error', t('common.saveFailed')); } } }} />
    </>
  );
}
