import { useState, type FormEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import { CheckCircle2, Mail, MapPin, MessageCircle, Phone } from 'lucide-react';
import { useI18n } from '../lib/i18n';
import { useSite } from '../lib/data';
import { sendMessage } from '../lib/api';
import { useTitle } from '../lib/useTitle';
import { extractMapUrl, isEmail, waLink } from '../lib/utils';
import { Button, Field, Input, Textarea } from '../components/ui';
import { Container, PageHead } from '../components/site/parts';

const COOLDOWN_KEY = 'naseem.lastMessage';

export default function ContactPage() {
  const { t, tr } = useI18n();
  const { settings } = useSite();
  const [params] = useSearchParams();
  const c = settings.company;
  useTitle(t('nav.contact'));

  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: params.get('subject') || '', message: '', website: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [state, setState] = useState<'idle' | 'sending' | 'sent' | 'failed'>('idle');
  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (form.website) return; // honeypot: real people never fill this field
    const next: Record<string, string> = {};
    if (form.name.trim().length < 2) next.name = t('contact.errName');
    if (!isEmail(form.email.trim())) next.email = t('contact.errEmail');
    if (form.message.trim().length < 5) next.message = t('contact.errMessage');
    setErrors(next);
    if (Object.keys(next).length) return;
    const last = Number(localStorage.getItem(COOLDOWN_KEY) || 0);
    if (Date.now() - last < 30000) { setErrors({ message: t('contact.errWait') }); return; }
    setState('sending');
    try {
      await sendMessage({ name: form.name.trim(), email: form.email.trim(), phone: form.phone.trim(), subject: form.subject.trim(), message: form.message.trim() });
      localStorage.setItem(COOLDOWN_KEY, String(Date.now()));
      setState('sent');
    } catch { setState('failed'); }
  };

  const map = extractMapUrl(c.mapUrl);
  const info = [
    tr(c.address) && { icon: MapPin, label: t('contact.address'), value: tr(c.address) },
    c.phone && { icon: Phone, label: t('contact.phone'), value: c.phone, href: `tel:${c.phone}`, ltr: true },
    c.email && { icon: Mail, label: t('contact.email'), value: c.email, href: `mailto:${c.email}` },
    c.whatsapp && { icon: MessageCircle, label: t('contact.whatsapp'), value: c.whatsapp, href: waLink(c.whatsapp), ltr: true },
  ].filter(Boolean) as Array<{ icon: typeof Mail; label: string; value: string; href?: string; ltr?: boolean }>;

  return (
    <>
      <PageHead title={t('nav.contact')} text={t('contact.subtitle')} />
      <Container className="grid gap-10 py-14 lg:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-[8px] border border-line bg-white p-6 md:p-9">
          {state === 'sent' ? (
            <div role="status" className="py-10 text-center">
              <CheckCircle2 className="mx-auto size-12 text-teal" aria-hidden />
              <h2 className="mt-4 text-2xl font-semibold text-pine">{t('contact.sentTitle')}</h2>
              <p className="mt-2 text-muted">{t('contact.sentText')}</p>
            </div>
          ) : (
            <form onSubmit={submit} noValidate className="grid gap-5 sm:grid-cols-2">
              <Field label={t('contact.name')} error={errors.name}><Input value={form.name} onChange={set('name')} autoComplete="name" maxLength={100} /></Field>
              <Field label={t('contact.email')} error={errors.email}><Input type="email" dir="ltr" value={form.email} onChange={set('email')} autoComplete="email" maxLength={160} /></Field>
              <Field label={t('contact.phone')}><Input type="tel" dir="ltr" value={form.phone} onChange={set('phone')} autoComplete="tel" maxLength={30} /></Field>
              <Field label={t('contact.subject')}><Input value={form.subject} onChange={set('subject')} maxLength={160} /></Field>
              <Field label={t('contact.message')} error={errors.message} className="sm:col-span-2"><Textarea rows={6} value={form.message} onChange={set('message')} maxLength={4000} /></Field>
              <input type="text" name="website" tabIndex={-1} autoComplete="off" value={form.website} onChange={set('website')} className="hidden" aria-hidden />
              <div className="sm:col-span-2">
                <Button type="submit" size="lg" loading={state === 'sending'}>{t('contact.send')}</Button>
                {state === 'failed' && <p role="alert" className="mt-3 text-sm font-medium text-danger">{t('contact.errSend')}</p>}
              </div>
            </form>
          )}
        </div>

        <aside className="space-y-6">
          <ul className="space-y-5 rounded-[8px] bg-pine p-7 text-white">
            {info.length === 0 && <li className="text-sm text-white/70">{tr(c.name)}</li>}
            {info.map(({ icon: Icon, label, value, href, ltr }) => (
              <li key={label} className="flex gap-4">
                <span className="grid size-10 shrink-0 -skew-x-[16deg] place-items-center bg-sand text-pine"><Icon className="size-5 skew-x-[16deg]" aria-hidden /></span>
                <div>
                  <p className="text-xs text-white/60">{label}</p>
                  {href ? <a href={href} dir={ltr ? 'ltr' : undefined} className="font-medium hover:text-sand">{value}</a> : <p className="font-medium">{value}</p>}
                </div>
              </li>
            ))}
          </ul>
          {map && <iframe title={t('contact.map')} src={map} loading="lazy" referrerPolicy="no-referrer-when-downgrade" className="h-64 w-full rounded-[8px] border border-line" />}
        </aside>
      </Container>
    </>
  );
}
