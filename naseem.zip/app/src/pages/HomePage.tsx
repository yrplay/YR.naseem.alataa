import { Link } from 'react-router-dom';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { useI18n } from '../lib/i18n';
import { useSite } from '../lib/data';
import { useTitle } from '../lib/useTitle';
import { Button, EmptyState, Spinner } from '../components/ui';
import { Container, ProductCard, SectionHead } from '../components/site/parts';

function Hero() {
  const { t, tr, dir } = useI18n();
  const { settings } = useSite();
  const Arrow = dir === 'rtl' ? ArrowLeft : ArrowRight;
  const title = tr(settings.hero.title) || tr(settings.company.name);
  return (
    <section className="hero-field on-dark relative overflow-hidden bg-pine pb-36 pt-16 text-white md:pt-24">
      <Container className="relative grid items-center gap-12 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <h1 className="hero-line max-w-3xl text-[2.6rem] font-semibold leading-[1.15] md:text-6xl md:leading-[1.12]">{title}</h1>
          {tr(settings.hero.subtitle) && (
            <p className="hero-line mt-6 max-w-xl text-lg text-white/80" style={{ animationDelay: '0.12s' }}>{tr(settings.hero.subtitle)}</p>
          )}
          <div className="hero-line mt-9 flex flex-wrap gap-3" style={{ animationDelay: '0.24s' }}>
            <Link to="/products"><Button variant="accent" size="lg">{t('home.browse')}<Arrow className="size-4" aria-hidden /></Button></Link>
            <Link to="/contact"><Button variant="outline" size="lg" className="!border-white/30 !bg-transparent !text-white hover:!border-sand hover:!text-sand">{t('home.contactUs')}</Button></Link>
          </div>
        </div>
        <div aria-hidden className="relative hidden h-[400px] lg:block">
          {settings.hero.image ? (
            <img src={settings.hero.image} alt="" className="slant-frame hero-line size-full object-cover" />
          ) : (
            <>
              <span className="hero-bar absolute inset-y-6 start-[6%] w-32 bg-teal" />
              <span className="hero-bar absolute inset-y-0 start-[34%] w-44 bg-sand" style={{ animationDelay: '0.1s', ['--from' as string]: '90px' }} />
              <span className="hero-bar absolute inset-y-10 start-[72%] w-20 bg-tint/90" style={{ animationDelay: '0.2s', ['--from' as string]: '120px' }} />
            </>
          )}
        </div>
      </Container>
    </section>
  );
}

export default function HomePage() {
  const { t, tr } = useI18n();
  const { settings, loaded, failed, categories, products, catalogLoading } = useSite();
  useTitle(tr(settings.company.name));
  if (!loaded) return <Spinner label={t('common.loading')} />;

  const featured = products.filter((p) => p.featured);
  const showcase = (featured.length ? featured : products).slice(0, 4);

  return (
    <>
      <Hero />

      {failed && <Container className="-mt-16 pb-10"><EmptyState title={t('home.failedTitle')} text={t('home.failedText')} /></Container>}

      {settings.services.length > 0 && (
        <section className="py-10 md:py-16">
          <Container className="grid gap-10 lg:grid-cols-[320px_1fr]">
            <div>
              <h2 className="text-3xl font-semibold text-pine md:text-4xl">{t('home.servicesTitle')}</h2>
              <p className="mt-3 text-muted">{t('home.servicesText')}</p>
            </div>
            <ul className="divide-y divide-line border-y border-line">
              {settings.services.map((s) => (
                <li key={s.id} className="flex gap-5 py-6">
                  <span aria-hidden className="mt-1.5 h-7 w-2.5 shrink-0 -skew-x-[16deg] bg-sand" />
                  <div>
                    <h3 className="text-xl font-semibold text-pine">{tr(s.title)}</h3>
                    <p className="mt-1.5 max-w-2xl text-muted">{tr(s.text)}</p>
                  </div>
                </li>
              ))}
            </ul>
          </Container>
        </section>
      )}

      {categories.length > 0 && (
        <section className="py-10 md:py-16">
          <Container>
            <SectionHead title={t('home.categoriesTitle')} text={t('home.categoriesText')} />
            <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {categories.filter((c) => c.active).slice(0, 8).map((c) => (
                <li key={c.id}>
                  <Link to={`/products?cat=${c.id}`} className="group relative flex h-full flex-col overflow-hidden rounded-[6px] border border-line bg-white p-6 transition-colors hover:border-teal">
                    <span aria-hidden className="absolute -end-5 -top-px h-16 w-14 -skew-x-[16deg] bg-tint transition-colors group-hover:bg-sand" />
                    {c.thumb && <img src={c.thumb} alt="" loading="lazy" className="relative mb-4 aspect-[16/10] w-full rounded-[4px] object-cover" />}
                    <h3 className="relative text-lg font-semibold text-pine">{tr(c.title)}</h3>
                    <p className="relative mt-2 line-clamp-3 text-sm text-muted">{tr(c.description)}</p>
                  </Link>
                </li>
              ))}
            </ul>
            {categories.length > 8 && <div className="mt-6"><Link to="/products" className="font-medium text-teal-d hover:underline">{t('home.allCategories')}</Link></div>}
          </Container>
        </section>
      )}

      {(catalogLoading || showcase.length > 0) && (
        <section className="py-10 md:py-16">
          <Container>
            <SectionHead
              title={t('home.productsTitle')}
              action={<Link to="/products" className="font-medium text-teal-d hover:underline">{t('home.allProducts')}</Link>}
            />
            {catalogLoading ? <Spinner /> : (
              <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
                {showcase.map((p) => <li key={p.id}><ProductCard product={p} /></li>)}
              </ul>
            )}
          </Container>
        </section>
      )}

      {settings.sectors.length > 0 && (
        <section className="on-dark my-10 bg-pine py-16 text-white md:py-20">
          <Container>
            <div className="mb-10 max-w-2xl">
              <h2 className="text-3xl font-semibold md:text-4xl">{t('home.sectorsTitle')}</h2>
              <p className="mt-3 text-white/70">{t('home.sectorsText')}</p>
            </div>
            <ul className="grid border-s border-t border-white/15 sm:grid-cols-2 lg:grid-cols-4">
              {settings.sectors.map((s) => (
                <li key={s.id} className="border-b border-e border-white/15 p-6">
                  <h3 className="text-lg font-semibold text-sand">{tr(s.title)}</h3>
                  <p className="mt-2 text-sm text-white/70">{tr(s.text)}</p>
                </li>
              ))}
            </ul>
          </Container>
        </section>
      )}

      <section className="py-10 md:py-16">
        <Container>
          <div className="relative overflow-hidden rounded-[8px] bg-teal px-7 py-12 text-white md:px-14">
            <span aria-hidden className="absolute inset-y-0 end-[10%] w-20 -skew-x-[16deg] bg-white/10" />
            <span aria-hidden className="absolute inset-y-0 end-[20%] w-8 -skew-x-[16deg] bg-sand/60" />
            <div className="relative max-w-xl">
              <h2 className="text-3xl font-semibold md:text-4xl">{t('home.ctaTitle')}</h2>
              <p className="mt-3 text-white/85">{t('home.ctaText')}</p>
              <Link to="/contact" className="mt-7 inline-block"><Button variant="accent" size="lg">{t('home.contactUs')}</Button></Link>
            </div>
          </div>
        </Container>
      </section>
    </>
  );
}

