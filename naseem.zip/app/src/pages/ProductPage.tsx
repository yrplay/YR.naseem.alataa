import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, ArrowRight, MessageCircle } from 'lucide-react';
import { useI18n } from '../lib/i18n';
import { useSite } from '../lib/data';
import { loadProductImages } from '../lib/api';
import { useTitle } from '../lib/useTitle';
import { cn, formatPrice, lines, waLink } from '../lib/utils';
import { Button, EmptyState, Spinner } from '../components/ui';
import { Container, LogoPlaceholder } from '../components/site/parts';

export default function ProductPage() {
  const { id = '' } = useParams();
  const { t, tr, lang, dir } = useI18n();
  const { products, categories, settings, catalogLoading } = useSite();
  const product = products.find((p) => p.id === id);
  const [images, setImages] = useState<string[]>([]);
  const [index, setIndex] = useState(0);
  useTitle(product ? tr(product.title) : t('nav.products'));

  useEffect(() => {
    setIndex(0);
    setImages([]);
    let alive = true;
    if (id) void loadProductImages(id).then((imgs) => alive && setImages(imgs));
    return () => { alive = false; };
  }, [id]);

  const Back = dir === 'rtl' ? ArrowRight : ArrowLeft;
  if (catalogLoading) return <Spinner label={t('common.loading')} />;
  if (!product) {
    return <Container className="py-20"><EmptyState title={t('product.notFound')} action={<Link to="/products"><Button>{t('product.backToList')}</Button></Link>} /></Container>;
  }

  const cat = categories.find((c) => c.id === product.categoryId);
  const gallery = images.length ? images : product.thumb ? [product.thumb] : [];
  const inquiry = `${t('product.inquiryPrefix')} ${tr(product.title)}`;
  const paras = lines(tr(product.description));

  return (
    <Container className="py-10 md:py-14">
      <Link to="/products" className="mb-8 inline-flex items-center gap-2 text-sm font-medium text-teal-d hover:underline"><Back className="size-4" aria-hidden />{t('product.backToList')}</Link>
      <div className="grid gap-10 lg:grid-cols-2">
        <div>
          <div className="aspect-square overflow-hidden rounded-[6px] border border-line bg-white">
            {gallery[index] ? <img src={gallery[index]} alt={tr(product.title)} className="size-full object-contain" /> : <LogoPlaceholder />}
          </div>
          {gallery.length > 1 && (
            <ul className="mt-3 flex gap-2">
              {gallery.map((src, i) => (
                <li key={i}>
                  <button onClick={() => setIndex(i)} aria-label={`${i + 1}`} className={cn('size-20 overflow-hidden rounded-[4px] border-2', i === index ? 'border-sand' : 'border-line')}>
                    <img src={src} alt="" className="size-full object-cover" />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div>
          {cat && <Link to={`/products?cat=${cat.id}`} className="slant-tab inline-block bg-tint px-4 py-1 text-sm font-medium text-teal-d hover:bg-teal hover:text-white">{tr(cat.title)}</Link>}
          <h1 className="mt-4 text-3xl font-semibold text-pine md:text-4xl">{tr(product.title)}</h1>
          {product.sku && <p className="mt-2 text-sm text-muted" dir="ltr">SKU: {product.sku}</p>}
          {product.price != null && <p className="mt-5 text-2xl font-semibold text-sand-d">{formatPrice(product.price, lang)}</p>}
          <div className="prose-ar mt-6 max-w-xl text-[16px] text-ink/85">{paras.map((p, i) => <p key={i}>{p}</p>)}</div>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link to={`/contact?subject=${encodeURIComponent(inquiry)}`}><Button size="lg">{t('product.inquire')}</Button></Link>
            {settings.company.whatsapp && (
              <a href={`${waLink(settings.company.whatsapp)}?text=${encodeURIComponent(inquiry)}`} target="_blank" rel="noopener noreferrer">
                <Button size="lg" variant="outline"><MessageCircle className="size-4" aria-hidden />{t('contact.whatsapp')}</Button>
              </a>
            )}
          </div>
        </div>
      </div>
    </Container>
  );
}
