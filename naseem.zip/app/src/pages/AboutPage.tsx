import { useI18n } from '../lib/i18n';
import { useSite } from '../lib/data';
import { useTitle } from '../lib/useTitle';
import { lines } from '../lib/utils';
import { Container, PageHead, SectionHead } from '../components/site/parts';

export default function AboutPage() {
  const { t, tr } = useI18n();
  const { settings } = useSite();
  const a = settings.about;
  useTitle(t('nav.about'));
  const values = lines(tr(a.values));
  return (
    <>
      <PageHead title={t('nav.about')} text={tr(settings.company.name)} />
      <Container className="py-14">
        <div className={`grid gap-10 ${a.image ? 'lg:grid-cols-[1.2fr_0.8fr]' : ''}`}>
          <div className="prose-ar max-w-3xl text-[17px] leading-8 text-ink/90">
            {lines(tr(a.intro)).map((p, i) => <p key={i}>{p}</p>)}
          </div>
          {a.image && <img src={a.image} alt="" className="slant-frame h-full max-h-[420px] w-full object-cover" />}
        </div>

        {(tr(a.vision) || tr(a.mission)) && (
          <div className="mt-16 grid gap-px overflow-hidden rounded-[6px] bg-line md:grid-cols-2">
            {[{ h: t('about.vision'), v: a.vision }, { h: t('about.mission'), v: a.mission }].filter((x) => tr(x.v)).map((x) => (
              <section key={x.h} className="bg-white p-8">
                <h2 className="flex items-center gap-3 text-2xl font-semibold text-pine"><span aria-hidden className="h-6 w-2 -skew-x-[16deg] bg-sand" />{x.h}</h2>
                <p className="mt-4 text-ink/85">{tr(x.v)}</p>
              </section>
            ))}
          </div>
        )}

        {values.length > 0 && (
          <section className="mt-16">
            <SectionHead title={t('about.values')} />
            <ul className="flex flex-wrap gap-3">
              {values.map((v) => <li key={v} className="slant-tab bg-pine px-7 py-2.5 font-medium text-white">{v}</li>)}
            </ul>
          </section>
        )}

        {settings.services.length > 0 && (
          <section className="mt-16">
            <SectionHead title={t('home.servicesTitle')} />
            <ul className="grid gap-4 md:grid-cols-2">
              {settings.services.map((s) => (
                <li key={s.id} className="rounded-[6px] border border-line border-s-4 border-s-teal bg-white p-6">
                  <h3 className="text-lg font-semibold text-pine">{tr(s.title)}</h3>
                  <p className="mt-1.5 text-sm text-muted">{tr(s.text)}</p>
                </li>
              ))}
            </ul>
          </section>
        )}
      </Container>
    </>
  );
}
